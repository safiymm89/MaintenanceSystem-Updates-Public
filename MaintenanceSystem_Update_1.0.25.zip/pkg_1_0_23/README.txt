MaintenanceSystem Update 1.0.25

This update is based on version 1.0.21 and preserves its employee editing controls and employee-name search behavior.
Changes:
- Restores the 1.0.21 employee autocomplete/search behavior so typing remains focused in the field.
- Keeps the 1.0.21 header/title and edit controls.
- Improves mouse-wheel scrolling inside the employee details and settings scrollable areas: scrolling works when the pointer is anywhere inside the relevant panel, not only on the scrollbar.
- No database is included.
