# -*- coding: utf-8 -*-
"""Safe updater for Maintenance System.

GitHub provides update metadata and update ZIPs. The local SQLite database is
never replaced by an update. On Windows the replacement is performed by a
small detached batch process after the application closes.
"""
import json
import urllib.request
import tempfile
import zipfile
import shutil
import hashlib
import subprocess
import os
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
VERSION_FILE = BASE_DIR / "version.json"
DEFAULT_UPDATE_URL = (
    "https://raw.githubusercontent.com/safiymm89/"
    "MaintenanceSystem-Updates-Public/main/version.json"
)
DB_NAME = "maintenance_data.sqlite"


def current_version():
    try:
        return json.loads(VERSION_FILE.read_text(encoding="utf-8")).get("version", "1.0.0")
    except Exception:
        return "1.0.0"


def _ver(v):
    parts = str(v or "0").strip().lstrip("v").split(".")
    result = []
    for x in parts:
        digits = "".join(ch for ch in x if ch.isdigit())
        result.append(int(digits or 0))
    return tuple((result + [0, 0, 0])[:3])


def check_update(url=None, timeout=15):
    url = (url or DEFAULT_UPDATE_URL).strip() or DEFAULT_UPDATE_URL
    request = urllib.request.Request(url, headers={"User-Agent": "MaintenanceSystem-Updater/1.1"})
    with urllib.request.urlopen(request, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8-sig"))
    remote = data.get("version", "1.0.0")
    return data, _ver(remote) > _ver(current_version())


def resolve_download_url(data, metadata_url=None):
    """Accept download_url or the older download field used by the repository.

    A bare filename is resolved relative to the same GitHub raw directory as
    version.json, so the repository can keep version.json simple.
    """
    raw = str(data.get("download_url") or data.get("download") or "").strip()
    if not raw:
        return ""
    if raw.startswith(("http://", "https://")):
        return raw
    base = str(metadata_url or DEFAULT_UPDATE_URL).strip()
    if "/" in base:
        return base.rsplit("/", 1)[0] + "/" + raw.lstrip("/")
    return raw


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_extract(zpath, extract):
    root = extract.resolve()
    with zipfile.ZipFile(zpath) as z:
        for member in z.infolist():
            target = (extract / member.filename).resolve()
            if target != root and root not in target.parents:
                raise RuntimeError("ملف التحديث يحتوي على مسار غير آمن.")
        z.extractall(extract)


def _find_source(extract):
    source = extract
    nested = [p for p in extract.iterdir() if p.name != "__MACOSX"]
    if len(nested) == 1 and nested[0].is_dir():
        source = nested[0]
    return source


def _write_update_bat(staging, target_dir, pid=None):
    """Create a detached Windows updater that waits for the app to exit."""
    staging = Path(staging).resolve()
    target_dir = Path(target_dir).resolve()
    bat = target_dir / "_apply_update.bat"
    app_pid = str(pid or os.getpid())
    lines = [
        "@echo off",
        "setlocal",
        f'set "STAGING={staging}"',
        f'set "TARGET={target_dir}"',
        f'set "PID={app_pid}"',
        ":waitloop",
        'tasklist /FI "PID eq %PID%" 2>NUL | find /I "%PID%" >NUL',
        'if not errorlevel 1 (timeout /t 1 /nobreak >NUL & goto waitloop)',
        'timeout /t 1 /nobreak >NUL',
        'robocopy "%STAGING%" "%TARGET%" /E /XF "maintenance_data.sqlite" "*.bak" "_apply_update.bat" /R:3 /W:1 >NUL',
        'if errorlevel 8 (echo UPDATE_FAILED> "%TARGET%\\update_error.txt" & exit /b 1)',
        'rmdir /S /Q "%STAGING%" >NUL 2>NUL',
        'del /F /Q "%TARGET%\\_apply_update.bat" >NUL 2>NUL',
        'start "" "%TARGET%\\run_system.bat"',
        'endlocal',
    ]
    bat.write_text("\r\n".join(lines) + "\r\n", encoding="utf-8")
    return bat


def install_zip(zip_url, expected_sha256="", timeout=60, restart=True):
    """Download, verify, stage and apply an update without replacing SQLite."""
    if not zip_url:
        raise RuntimeError("رابط تحميل التحديث غير موجود.")

    db = BASE_DIR / DB_NAME
    if db.exists():
        shutil.copy2(db, BASE_DIR / "maintenance_data_before_update.sqlite.bak")

    work_root = BASE_DIR / "_update_work"
    work_root.mkdir(exist_ok=True)
    stage = work_root / ("package_" + str(int(time.time())))
    stage.mkdir(parents=True, exist_ok=False)

    try:
        zpath = stage / "update.zip"
        request = urllib.request.Request(zip_url, headers={"User-Agent": "MaintenanceSystem-Updater/1.1"})
        with urllib.request.urlopen(request, timeout=timeout) as response, open(zpath, "wb") as out:
            shutil.copyfileobj(response, out)

        if expected_sha256 and _sha256(zpath).lower() != expected_sha256.lower():
            raise RuntimeError("فشل التحقق من سلامة ملف التحديث (SHA-256).")

        extract = stage / "extract"
        extract.mkdir()
        _safe_extract(zpath, extract)
        source = _find_source(extract)

        # Keep only the files that will be copied later; never stage the user's DB.
        final_stage = stage / "payload"
        final_stage.mkdir()
        for p in source.iterdir():
            if p.name == DB_NAME or p.name.endswith(".bak") or p.name == "_update_work":
                continue
            dest = final_stage / p.name
            if p.is_dir():
                shutil.copytree(p, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(p, dest)

        if restart:
            bat = _write_update_bat(final_stage, BASE_DIR, os.getpid())
            subprocess.Popen(
                ["cmd.exe", "/c", "start", "", "/min", str(bat)],
                cwd=str(BASE_DIR),
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                close_fds=True,
            )
            return {"scheduled": True, "restart": True}

        for p in final_stage.iterdir():
            dest = BASE_DIR / p.name
            if p.is_dir():
                shutil.copytree(p, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(p, dest)
        shutil.rmtree(stage, ignore_errors=True)
        return {"scheduled": False, "restart": False}
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise
