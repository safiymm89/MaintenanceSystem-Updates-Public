# -*- coding: utf-8 -*-
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from pathlib import Path
from datetime import datetime
import shutil
import hashlib
import json
import webbrowser
import subprocess
import sys
import calendar as pycalendar

try:
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    GOOGLE_LIBS_AVAILABLE = True
except Exception:
    GOOGLE_LIBS_AVAILABLE = False

APP_TITLE = "إدارة نظام الموظفين"
DB_NAME = "maintenance_data.sqlite"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / DB_NAME

def _is_valid_db(path):
    try:
        conn = sqlite3.connect(str(path))
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type=\"table\"")}
        conn.close()
        required = {"المنتسبون", "الإجازات", "الغيابات", "العقوبات", "الحضور"}
        return required.issubset(tables)
    except Exception:
        return False

def locate_database():
    """Find the user's existing database without creating/replacing it."""
    exact = BASE_DIR / DB_NAME
    if exact.exists():
        return exact

    candidates = []
    folders = [BASE_DIR, BASE_DIR.parent]
    for folder in folders:
        if not folder.exists():
            continue
        for ext in ("*.sqlite", "*.db"):
            for p in folder.glob(ext):
                if p.is_file() and _is_valid_db(p):
                    if p not in candidates:
                        candidates.append(p)
    if len(candidates) == 1:
        return candidates[0]
    return None

DB_PATH = locate_database() or (BASE_DIR / DB_NAME)

def _norm_date(value):
    value=("" if value is None else str(value)).strip().replace("\\","/")
    for fmt in ("%Y-%m-%d","%d/%m/%Y","%-d/%-m/%Y"):
        try:
            return datetime.strptime(value,fmt).strftime("%Y-%m-%d")
        except Exception:
            pass
    # Windows/Linux formatting fallback for one-digit day/month.
    try:
        parts=value.split("/")
        if len(parts)==3 and len(parts[2])==4:
            d,m,y=map(int,parts)
            return datetime(y,m,d).strftime("%Y-%m-%d")
    except Exception:
        pass
    return ""

class DatePicker(tk.Toplevel):
    """تقويم بسيط لاختيار تاريخ صحيح فقط."""
    def __init__(self, parent, variable, title="اختيار التاريخ"):
        super().__init__(parent)
        self.parent = parent
        self.variable = variable
        self.title(title)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.today = datetime.now()
        self.year, self.month = self._initial_month()
        self._build()
        self._render()
        self.protocol("WM_DELETE_WINDOW", self.destroy)

    def _initial_month(self):
        value = (self.variable.get() or "").strip()
        for fmt in ("%Y-%m-%d", "%d\\%m\\%Y", "%d/%m/%Y", "%Y"):
            try:
                d = datetime.strptime(value, fmt)
                return d.year, d.month
            except Exception:
                pass
        return self.today.year, self.today.month

    def _build(self):
        top = ttk.Frame(self, padding=8)
        top.pack(fill="x")
        ttk.Button(top, text="السنة السابقة", width=10, command=self.prev_year).pack(side="left", padx=2)
        self.year_var = tk.StringVar(value=str(self.year))
        self.year_spin = ttk.Spinbox(top, from_=1900, to=2100, width=7, textvariable=self.year_var, justify="center", command=self.change_year)
        self.year_spin.pack(side="left", padx=4)
        self.year_spin.bind("<Return>", lambda e: self.change_year())
        ttk.Button(top, text="السنة التالية", width=10, command=self.next_year).pack(side="left", padx=2)
        ttk.Button(top, text="‹", width=3, command=self.prev_month).pack(side="right", padx=2)
        self.month_label = ttk.Label(top, width=14, anchor="center", font=("Tahoma", 11, "bold"))
        self.month_label.pack(side="right", expand=True)
        ttk.Button(top, text="›", width=3, command=self.next_month).pack(side="right", padx=2)

        days = ["السبت","الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة"]
        self.grid_frame = ttk.Frame(self, padding=(8,0,8,8))
        self.grid_frame.pack()
        for c, name in enumerate(days):
            ttk.Label(self.grid_frame, text=name, width=8, anchor="center").grid(row=0,column=c,padx=1,pady=2)

        bottom = ttk.Frame(self, padding=8)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="اليوم", command=self.choose_today).pack(side="right", padx=2)
        ttk.Button(bottom, text="مسح", command=self.clear_date).pack(side="right", padx=2)
        ttk.Button(bottom, text="إلغاء", command=self.destroy).pack(side="left", padx=2)

    def _render(self):
        for w in self.grid_frame.winfo_children()[7:]:
            w.destroy()
        months = ["كانون الثاني","شباط","آذار","نيسان","أيار","حزيران","تموز","آب","أيلول","تشرين الأول","تشرين الثاني","كانون الأول"]
        self.month_label.config(text=f"{months[self.month-1]} {self.year}")
        weeks = pycalendar.Calendar(firstweekday=5).monthdayscalendar(self.year, self.month)
        for r, week in enumerate(weeks, start=1):
            for c, day in enumerate(week):
                if day == 0:
                    continue
                ttk.Button(self.grid_frame, text=str(day), width=6,
                           command=lambda d=day: self.choose_day(d)).grid(row=r,column=c,padx=1,pady=1)

    def change_year(self):
        try:
            year = int(self.year_var.get())
            if 1900 <= year <= 2100:
                self.year = year
                self.year_var.set(str(self.year))
                self._render()
            else:
                self.year_var.set(str(self.year))
        except Exception:
            self.year_var.set(str(self.year))

    def prev_year(self):
        if self.year > 1900:
            self.year -= 1
            self.year_var.set(str(self.year))
            self._render()

    def next_year(self):
        if self.year < 2100:
            self.year += 1
            self.year_var.set(str(self.year))
            self._render()

    def prev_month(self):
        self.month -= 1
        if self.month == 0:
            self.month, self.year = 12, self.year - 1
        self.year_var.set(str(self.year))
        self._render()

    def next_month(self):
        self.month += 1
        if self.month == 13:
            self.month, self.year = 1, self.year + 1
        self.year_var.set(str(self.year))
        self._render()

    def choose_day(self, day):
        self.variable.set(f"{self.year:04d}-{self.month:02d}-{day:02d}")
        self.destroy()

    def choose_today(self):
        self.variable.set(self.today.strftime("%Y-%m-%d"))
        self.destroy()

    def clear_date(self):
        self.variable.set("")
        self.destroy()

class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1250x760")
        self.root.minsize(1050, 650)
        self.root.option_add("*Font", ("Tahoma", 10))
        self.conn = None
        self.selected_employee_id = None
        self.selected_leave_id = None
        self.selected_absence_id = None
        self.selected_penalty_id = None
        self.selected_attendance_id = None

        if not DB_PATH.exists():
            messagebox.showerror("قاعدة البيانات",
                "لم يتم العثور على قاعدة البيانات.\n\nضع ملف قاعدة البيانات بجانب البرنامج أو اختره من شاشة اختيار قاعدة البيانات.")
            root.destroy()
            return
        try:
            self.conn = sqlite3.connect(str(DB_PATH))
            self.conn.create_function("normdate", 1, _norm_date)
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.validate_db()
            self.ensure_employee_fields()
            self.ensure_leave_fields()
            self.ensure_settings()
        except Exception as e:
            messagebox.showerror("خطأ", f"تعذر فتح قاعدة البيانات:\n{e}")
            root.destroy()
            return

        self.build_ui()
        self.load_all()

    def validate_db(self):
        required = {"المنتسبون","الإجازات","الغيابات","العقوبات","الحضور"}
        found = {r[0] for r in self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        missing = required - found
        if missing:
            raise RuntimeError("الجداول التالية مفقودة: " + ", ".join(sorted(missing)))
        if "الأقسام" not in found:
            # The main system can work with the newer "الشعب" hierarchy.
            if "الشعب" not in found:
                raise RuntimeError("جدول الأقسام/الشعب مفقود من قاعدة البيانات.")

    def ensure_employee_fields(self):
        """إضافة الحقول الجديدة إن لم تكن موجودة مع الحفاظ على جميع البيانات السابقة."""
        existing = {r[1] for r in self.conn.execute("PRAGMA table_info(المنتسبون)")}
        new_fields = {
            "رقم_الباج": "TEXT",
            "رقم_البطاقة_الوطنية": "TEXT",
            "عدد_الأطفال": "INTEGER"
        }
        for name, typ in new_fields.items():
            if name not in existing:
                self.conn.execute(f'ALTER TABLE "المنتسبون" ADD COLUMN "{name}" {typ}')
        self.conn.commit()

    def ensure_leave_fields(self):
        """إضافة حقول الإجازة الزمنية مع الحفاظ على السجلات القديمة."""
        existing = {r[1] for r in self.conn.execute("PRAGMA table_info(الإجازات)")}
        new_fields = {
            "تاريخ_الإجازة": "TEXT",
            "من_الساعة": "TEXT",
            "إلى_الساعة": "TEXT",
            "عدد_الساعات": "TEXT"
        }
        for name, typ in new_fields.items():
            if name not in existing:
                self.conn.execute(f'ALTER TABLE "الإجازات" ADD COLUMN "{name}" {typ}')
        self.conn.commit()

    def q(self, sql, params=()):
        return self.conn.execute(sql, params)

    def commit(self):
        self.conn.commit()

    def build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        # رأس النظام
        header = ttk.Frame(self.root, padding=(18, 10, 18, 6))
        header.pack(fill="x")

        brand = ttk.Frame(header)
        brand.pack(side="right")

        self.header_logo = tk.Canvas(brand, width=60, height=60, highlightthickness=0, bd=0)
        self.header_logo.pack(side="right", padx=(0, 12))
        self._draw_admin_logo("#1677e8", "#ffffff")

        title_box = ttk.Frame(brand)
        title_box.pack(side="right", padx=(0, 8))
        self.header_title = ttk.Label(title_box, text="إدارة نظام الموظفين", font=("Tahoma", 27, "bold"))
        self.header_title.pack(anchor="e")
        self.header_subtitle = ttk.Label(title_box, text="شعبة الصيانة  •  الإدارة والمتابعة", font=("Tahoma", 11))
        self.header_subtitle.pack(anchor="e", pady=(2, 0))

        tools = ttk.Frame(header)
        tools.pack(side="left", fill="y")
        ttk.Button(tools, text="نسخ احتياطي", command=self.backup_db).pack(side="left", padx=4, pady=4)
        ttk.Button(tools, text="تحديث البيانات", command=self.load_all).pack(side="left", padx=4, pady=4)
        ttk.Button(tools, text="فحص تحديث البرنامج", command=self.check_program_update).pack(side="left", padx=4, pady=4)

        # شريط تنقل على شكل أزرار كبسولة (مشابه للتصميم المطلوب)
        self.nb = ttk.Notebook(self.root, style="Hidden.TNotebook")
        self.nb.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.build_employees_tab()
        self.build_leaves_tab()
        self.build_absences_tab()
        self.build_penalties_tab()
        self.build_attendance_tab()
        self.build_sections_tab()
        self.build_reports_tab()
        self.build_settings_tab()

        self.nav_bar = tk.Frame(self.root, bg="#f5f7fb", height=58)
        self.nav_bar.pack(fill="x", padx=18, pady=(0, 8), before=self.nb)
        self.nav_items = []
        tab_labels = [
            ("الموظفون", "#1976d2", "#e8f2ff"),
            ("الإجازات", "#0288d1", "#e7f7ff"),
            ("الغيابات", "#d9534f", "#fff0ef"),
            ("العقوبات", "#d98b16", "#fff6e3"),
            ("الحضور", "#2e9d68", "#eaf8f1"),
            ("الشعب", "#7956c8", "#f2edff"),
            ("التقارير", "#008c95", "#e8fbfc"),
            ("الإعدادات", "#64748b", "#eef2f6"),
        ]
        for i, (label, active, inactive) in enumerate(tab_labels):
            self._make_nav_pill(i, label, active, inactive)
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self._refresh_nav_pills())
        self._refresh_nav_pills()

    def _make_nav_pill(self, index, label, active, inactive):
        cv = tk.Canvas(self.nav_bar, width=126, height=46, bg="#f5f7fb", highlightthickness=0, bd=0, cursor="hand2")
        cv.pack(side="right", padx=5, pady=6)
        item = {"canvas": cv, "label": label, "active": active, "inactive": inactive, "index": index}
        self.nav_items.append(item)
        cv.bind("<Button-1>", lambda e, i=index: self._select_nav(i))
        cv.bind("<Enter>", lambda e, i=index: self._hover_nav(i, True))
        cv.bind("<Leave>", lambda e, i=index: self._hover_nav(i, False))

    def _rounded_rect(self, c, x1, y1, x2, y2, r, fill, outline):
        # رسم كبسولة بدون الخطوط الداخلية التي كانت تمر فوق الكتابة.
        # نرسم الشكل الخارجي ثم الداخلي للحصول على حدود نظيفة ومتناسقة.
        if outline and outline != fill:
            c.create_oval(x1, y1, x1+2*r, y2, fill=outline, outline=outline)
            c.create_oval(x2-2*r, y1, x2, y2, fill=outline, outline=outline)
            c.create_rectangle(x1+r, y1, x2-r, y2, fill=outline, outline=outline)
            ix1, iy1, ix2, iy2 = x1+1, y1+1, x2-1, y2-1
            ir = max(1, r-1)
            c.create_oval(ix1, iy1, ix1+2*ir, iy2, fill=fill, outline=fill)
            c.create_oval(ix2-2*ir, iy1, ix2, iy2, fill=fill, outline=fill)
            c.create_rectangle(ix1+ir, iy1, ix2-ir, iy2, fill=fill, outline=fill)
        else:
            c.create_oval(x1, y1, x1+2*r, y2, fill=fill, outline=fill)
            c.create_oval(x2-2*r, y1, x2, y2, fill=fill, outline=fill)
            c.create_rectangle(x1+r, y1, x2-r, y2, fill=fill, outline=fill)

    def _refresh_nav_pills(self):
        try:
            selected = self.nb.index(self.nb.select())
        except Exception:
            selected = 0
        for item in self.nav_items:
            c = item["canvas"]
            c.delete("all")
            is_active = item["index"] == selected
            fill = item["active"] if is_active else item["inactive"]
            outline = item["active"] if is_active else "#d8dee8"
            text = "●  " + item["label"] if is_active else item["label"]
            self._rounded_rect(c, 2, 2, 124, 44, 20, fill, outline)
            c.create_text(63, 23, text=text, anchor="center", font=("Tahoma", 11, "bold"), fill="#ffffff" if is_active else "#253044")

    def _select_nav(self, index):
        try:
            self.nb.select(index)
            self._refresh_nav_pills()
        except Exception:
            pass

    def _hover_nav(self, index, entering):
        # إبراز خفيف عند المرور بدون تغيير حالة التبويب المختار
        if not self.nav_items:
            return
        item = self.nav_items[index]
        c = item["canvas"]
        try:
            selected = self.nb.index(self.nb.select())
        except Exception:
            selected = 0
        if index == selected:
            return
        c.delete("all")
        fill = "#ffffff" if entering else item["inactive"]
        self._rounded_rect(c, 2, 2, 124, 44, 20, fill, item["active"] if entering else "#d8dee8")
        c.create_text(63, 23, text=item["label"], anchor="center", font=("Tahoma", 11, "bold"), fill="#253044")

    def _draw_admin_logo(self, accent, light):
        c = self.header_logo
        c.delete("all")
        c.configure(bg="#ffffff")
        # دائرة الشعار
        c.create_oval(5, 5, 51, 51, fill=accent, outline=accent)
        # ترس مبسط بخطوط شعاعية + مركز
        import math
        cx, cy = 28, 28
        for angle in range(0, 360, 45):
            a = math.radians(angle)
            x1, y1 = cx + 10*math.cos(a), cy + 10*math.sin(a)
            x2, y2 = cx + 18*math.cos(a), cy + 18*math.sin(a)
            c.create_line(x1, y1, x2, y2, fill=light, width=4)
        c.create_oval(16, 16, 40, 40, fill=light, outline=light)
        c.create_oval(23, 23, 33, 33, fill=accent, outline=accent)

    def ensure_settings(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS إعدادات_النظام (
                المفتاح TEXT PRIMARY KEY,
                القيمة TEXT NOT NULL
            )
        """)
        row = self.conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='كلمة_المرور'"
        ).fetchone()
        if not row:
            self.conn.execute(
                "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)",
                ('كلمة_المرور', self.hash_password('1234'))
            )
        row = self.conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='لون_الواجهة'"
        ).fetchone()
        if not row:
            self.conn.execute(
                "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)",
                ('لون_الواجهة', 'أزرق')
            )
        defaults = {
            'البريد_الإلكتروني': '',
            'Google_Email': '',
            'Google_Sub': '',
            'لون_الخط': '',
            'لون_التحديد': '',
            'نوع_الخط': 'Tahoma',
            'حجم_الخط': '10',
            'وزن_الخط': 'عادي'
        }
        for k, v in defaults.items():
            if self.conn.execute("SELECT 1 FROM إعدادات_النظام WHERE المفتاح=?", (k,)).fetchone() is None:
                self.conn.execute("INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)", (k, v))
        # ترحيل البريد القديم إلى الاسم الجديد إذا كان موجوداً
        if not self.get_setting('البريد_الإلكتروني', ''):
            old_email = self.get_setting('بريد_الاستعادة', '')
            if old_email:
                self.set_setting('البريد_الإلكتروني', old_email)
        self.conn.commit()

    @staticmethod
    def hash_password(password):
        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def get_setting(self, key, default=''):
        row = self.conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح=?", (key,)
        ).fetchone()
        return row[0] if row else default

    def set_setting(self, key, value):
        self.conn.execute(
            "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?) "
            "ON CONFLICT(المفتاح) DO UPDATE SET القيمة=excluded.القيمة",
            (key, value)
        )
        self.conn.commit()

    def _current_font(self):
        family = self.get_setting('نوع_الخط', 'Tahoma') or 'Tahoma'
        try:
            size = int(self.get_setting('حجم_الخط', '10') or 10)
        except Exception:
            size = 10
        size = max(8, min(18, size))
        weight = 'bold' if self.get_setting('وزن_الخط', 'عادي') == 'عريض' else 'normal'
        return (family, size, weight)

    def _apply_font_to_widgets(self, widget, font):
        """تطبيق الخط المختار على عناصر الواجهة الحالية قدر الإمكان."""
        try:
            widget.configure(font=font)
        except Exception:
            pass
        for child in widget.winfo_children():
            self._apply_font_to_widgets(child, font)

    def apply_theme(self, theme_name=None):
        if not self.conn:
            return
        theme_name = theme_name or self.get_setting('لون_الواجهة', 'أزرق')
        palettes = {
            'أزرق': {'bg':'#eaf2f8', 'panel':'#ffffff', 'accent':'#1f4e78', 'fg':'#1f1f1f', 'entry':'#ffffff', 'select':'#cfe3f5'},
            'أخضر': {'bg':'#eaf7ee', 'panel':'#ffffff', 'accent':'#2e6b3e', 'fg':'#1f1f1f', 'entry':'#ffffff', 'select':'#d5eddc'},
            'رمادي': {'bg':'#eeeeee', 'panel':'#ffffff', 'accent':'#555555', 'fg':'#1f1f1f', 'entry':'#ffffff', 'select':'#d9d9d9'},
            'بني': {'bg':'#f5eee6', 'panel':'#ffffff', 'accent':'#795548', 'fg':'#1f1f1f', 'entry':'#ffffff', 'select':'#ead9cd'},
            'داكن خفيف': {'bg':'#d9dde1', 'panel':'#eef1f3', 'accent':'#2f7f9f', 'fg':'#20262b', 'entry':'#ffffff', 'select':'#b9d7e8'},
            'داكن متوسط': {'bg':'#30343b', 'panel':'#3b4048', 'accent':'#8fb3d9', 'fg':'#f0f0f0', 'entry':'#454b54', 'select':'#596675'},
            'داكن غامق': {'bg':'#17191c', 'panel':'#22252a', 'accent':'#9aa9ba', 'fg':'#f2f2f2', 'entry':'#2b2f35', 'select':'#41474f'},
        }
        pal = palettes.get(theme_name, palettes['أزرق']).copy()
        custom_fg = self.get_setting('لون_الخط', '').strip()
        custom_select = self.get_setting('لون_التحديد', '').strip()
        if custom_fg:
            pal['fg'] = custom_fg
        if custom_select:
            pal['select'] = custom_select
        bg, panel, accent, fg, entry_bg, select_bg = (pal[k] for k in ('bg','panel','accent','fg','entry','select'))
        font = self._current_font()
        style = ttk.Style(self.root)
        try:
            style.configure('TFrame', background=bg)
            style.configure('TLabelframe', background=bg)
            style.configure('TLabelframe.Label', background=bg, foreground=accent, font=font)
            style.configure('TLabel', background=bg, foreground=fg, font=font)
            style.configure('TButton', padding=5, background=panel, foreground=fg, font=font)
            style.map('TButton', background=[('active', select_bg), ('pressed', select_bg)], foreground=[('disabled', '#888888')])
            style.configure('TNotebook', background=bg, borderwidth=0, tabmargins=(6, 6, 6, 0))
            style.configure('TNotebook.Tab', padding=(12, 7), background=panel, foreground=fg, font=(font[0], max(10, font[1]), 'bold'), borderwidth=1, relief='raised')
            style.layout('Hidden.TNotebook.Tab', [])
            style.layout('Hidden.TNotebook', [('Notebook.client', {'sticky': 'nswe'})])
            style.configure('Hidden.TNotebook', background=bg, borderwidth=0, tabmargins=0)
            style.configure('App.TNotebook', background=bg, borderwidth=0, tabmargins=(6, 6, 6, 0))
            style.configure('App.TNotebook.Tab', padding=(18, 9), background='#f4f7fa', foreground=fg, font=(font[0], max(10, font[1]+1), 'bold'), borderwidth=1, relief='raised')
            style.map('App.TNotebook.Tab',
                      background=[('selected', accent), ('active', select_bg), ('pressed', accent)],
                      foreground=[('selected', '#ffffff'), ('active', fg), ('pressed', '#ffffff')],
                      relief=[('selected', 'sunken'), ('active', 'raised')])
            style.configure('Treeview', rowheight=max(25, font[1] + 16), background=panel, fieldbackground=panel, foreground=fg, font=font)
            style.map('Treeview', background=[('selected', select_bg)], foreground=[('selected', fg)])
            style.configure('Treeview.Heading', font=(font[0], font[1], 'bold'), background=accent, foreground='#ffffff')
            style.configure('TEntry', fieldbackground=entry_bg, foreground=fg, insertcolor=fg, font=font)
            style.configure('TCombobox', fieldbackground=entry_bg, background=panel, foreground=fg, arrowcolor=fg, font=font)
            style.map('TCombobox', fieldbackground=[('readonly', entry_bg)], foreground=[('readonly', fg)], selectbackground=[('readonly', select_bg)], selectforeground=[('readonly', fg)])
            style.configure('TSpinbox', fieldbackground=entry_bg, foreground=fg, arrowcolor=fg, font=font)
            style.configure('Vertical.TScrollbar', background=panel, troughcolor=bg, arrowcolor=fg)
            style.configure('Horizontal.TScrollbar', background=panel, troughcolor=bg, arrowcolor=fg)
            style.configure('TCheckbutton', background=bg, foreground=fg, font=font)
            style.configure('TRadiobutton', background=bg, foreground=fg, font=font)
        except Exception:
            pass
        self.root.configure(bg=bg)
        if hasattr(self, 'header_logo'):
            self.header_logo.configure(bg=panel)
            self._draw_admin_logo(accent, '#ffffff')
        if hasattr(self, 'header_title'):
            self.header_title.configure(foreground=fg, font=(font[0], max(22, font[1]+12), 'bold'))
        if hasattr(self, 'header_subtitle'):
            self.header_subtitle.configure(foreground=accent, font=(font[0], max(10, font[1]), 'bold'))
        try:
            self._apply_font_to_widgets(self.root, font)
        except Exception:
            pass
        if hasattr(self, 'text_color_sample'):
            self.text_color_sample.configure(bg=fg)
        if hasattr(self, 'selection_color_sample'):
            self.selection_color_sample.configure(bg=select_bg)

    def check_program_update(self):
        try:
            from updater import check_update, install_zip, resolve_download_url
            cfg = json.loads((BASE_DIR / "version.json").read_text(encoding="utf-8"))
            # GitHub هو خادم التحديث المركزي للنظام.
            # إذا كانت النسخة القديمة لا تحتوي الرابط، يستخدم updater الرابط الافتراضي.
            url = (cfg.get("update_url") or "").strip()
            data, available = check_update(url)
            if not available:
                messagebox.showinfo("تحديث البرنامج", f"البرنامج محدث. الإصدار الحالي: {cfg.get('version','1.0.0')}")
                return
            if not messagebox.askyesno("تحديث متوفر", f"يتوفر الإصدار {data.get('version')}. هل تريد التحديث الآن؟"):
                return
            download = resolve_download_url(data, url)
            if not download:
                messagebox.showerror("تحديث البرنامج", "رابط تحميل التحديث غير موجود في بيانات الخادم.")
                return
            result = install_zip(download, (data.get('sha256') or '').strip(), restart=True)
            if result.get("scheduled"):
                messagebox.showinfo("تحديث البرنامج", "تم تجهيز التحديث. سيغلق البرنامج الآن ويُكمل التحديث تلقائياً ثم يعيد التشغيل.")
                self.close()
                return
        except Exception as e:
            messagebox.showerror("تحديث البرنامج", f"تعذر فحص التحديث:\n{e}")

    def build_settings_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text='الإعدادات')

        # حاوية قابلة للتمرير حتى تظهر جميع إعدادات النظام على الشاشات الصغيرة
        scroll_frame = ttk.Frame(tab)
        scroll_frame.pack(fill='both', expand=True)
        settings_canvas = tk.Canvas(scroll_frame, highlightthickness=0, borderwidth=0)
        settings_scroll = ttk.Scrollbar(scroll_frame, orient='vertical', command=settings_canvas.yview)
        settings_canvas.configure(yscrollcommand=settings_scroll.set)
        settings_scroll.pack(side='right', fill='y')
        settings_canvas.pack(side='left', fill='both', expand=True)
        settings_inner = ttk.Frame(settings_canvas)
        settings_window = settings_canvas.create_window((0, 0), window=settings_inner, anchor='nw')

        def _settings_configure(event=None):
            settings_canvas.configure(scrollregion=settings_canvas.bbox('all'))
            settings_canvas.itemconfigure(settings_window, width=settings_canvas.winfo_width())
        settings_inner.bind('<Configure>', _settings_configure)
        settings_canvas.bind('<Configure>', _settings_configure)
        settings_canvas.bind_all('<MouseWheel>', lambda e: settings_canvas.yview_scroll(int(-e.delta/120), 'units'))
        settings_canvas.bind_all('<Button-4>', lambda e: settings_canvas.yview_scroll(-3, 'units'))
        settings_canvas.bind_all('<Button-5>', lambda e: settings_canvas.yview_scroll(3, 'units'))

        box = ttk.LabelFrame(settings_inner, text='إعدادات النظام', padding=15)
        box.pack(fill='x', padx=20, pady=20)

        ttk.Label(box, text='تسجيل الدخول والحساب', font=('Tahoma', 12, 'bold')).grid(row=0, column=0, columnspan=3, sticky='e', pady=(0,10))
        ttk.Label(box, text='كلمة المرور:').grid(row=1, column=0, padx=8, pady=8, sticky='e')
        ttk.Button(box, text='تغيير كلمة المرور', command=self.change_password).grid(row=1, column=1, padx=8, pady=8, sticky='w')

        ttk.Label(box, text='البريد الإلكتروني:').grid(row=2, column=0, padx=8, pady=8, sticky='e')
        self.email_var = tk.StringVar(value=self.get_setting('البريد_الإلكتروني', ''))
        ttk.Entry(box, textvariable=self.email_var, width=34).grid(row=2, column=1, padx=8, pady=8, sticky='w')
        ttk.Button(box, text='حفظ البريد', command=self.save_email).grid(row=2, column=2, padx=8, pady=8)

        ttk.Label(box, text='حساب Google:').grid(row=3, column=0, padx=8, pady=8, sticky='e')
        google_email = self.get_setting('Google_Email', '')
        self.google_status_var = tk.StringVar(value=google_email if google_email else 'غير مربوط')
        ttk.Label(box, textvariable=self.google_status_var).grid(row=3, column=1, padx=8, pady=8, sticky='w')
        ttk.Button(box, text='ربط / تسجيل الدخول بحساب Google', command=self.link_google_account).grid(row=3, column=2, padx=8, pady=8)

        ttk.Button(box, text='إزالة ربط Google', command=self.unlink_google_account).grid(row=4, column=2, padx=8, pady=8)


        theme_box = ttk.LabelFrame(settings_inner, text='مظهر النظام', padding=15)
        theme_box.pack(fill='x', padx=20, pady=(0,20))
        ttk.Label(theme_box, text='لون الواجهة:').grid(row=0, column=0, padx=8, pady=8, sticky='e')
        self.theme_var = tk.StringVar(value=self.get_setting('لون_الواجهة', 'أزرق'))
        theme_combo = ttk.Combobox(theme_box, textvariable=self.theme_var,
                                   values=['أزرق', 'أخضر', 'رمادي', 'بني', 'داكن خفيف', 'داكن متوسط', 'داكن غامق'],
                                   state='readonly', width=18)
        theme_combo.grid(row=0, column=1, padx=8, pady=8, sticky='w')
        theme_combo.bind('<<ComboboxSelected>>', self.change_theme)

        ttk.Label(theme_box, text='لون الخط:').grid(row=1, column=0, padx=8, pady=8, sticky='e')
        current_fg = self.get_setting('لون_الخط', '') or '#20262b'
        self.text_color_sample = tk.Button(theme_box, text=current_fg, width=18, relief='solid', bd=1,
                                           bg=current_fg, fg='#ffffff', command=self.choose_text_color)
        self.text_color_sample.grid(row=1, column=1, padx=8, pady=8, sticky='w')

        ttk.Label(theme_box, text='لون التحديد:').grid(row=2, column=0, padx=8, pady=8, sticky='e')
        current_select = self.get_setting('لون_التحديد', '') or '#b9d7e8'
        self.selection_color_sample = tk.Button(theme_box, text=current_select, width=18, relief='solid', bd=1,
                                                bg=current_select, fg='#20262b', command=self.choose_selection_color)
        self.selection_color_sample.grid(row=2, column=1, padx=8, pady=8, sticky='w')

        ttk.Button(theme_box, text='إرجاع ألوان الوضع الافتراضية', command=self.reset_custom_colors).grid(row=3, column=1, padx=8, pady=8, sticky='w')

        ttk.Label(theme_box, text='نوع الخط:').grid(row=4, column=0, padx=8, pady=8, sticky='e')
        self.font_family_var = tk.StringVar(value=self.get_setting('نوع_الخط', 'Tahoma'))
        font_combo = ttk.Combobox(theme_box, textvariable=self.font_family_var,
                                   values=['Tahoma', 'Arial', 'Segoe UI', 'Calibri', 'Times New Roman'],
                                   state='readonly', width=20)
        font_combo.grid(row=4, column=1, padx=8, pady=8, sticky='w')
        font_combo.bind('<<ComboboxSelected>>', self.change_font_settings)

        ttk.Label(theme_box, text='حجم الخط:').grid(row=5, column=0, padx=8, pady=8, sticky='e')
        self.font_size_var = tk.StringVar(value=self.get_setting('حجم_الخط', '10'))
        size_combo = ttk.Combobox(theme_box, textvariable=self.font_size_var,
                                   values=['8','9','10','11','12','13','14','15','16','18'],
                                   state='readonly', width=20)
        size_combo.grid(row=5, column=1, padx=8, pady=8, sticky='w')
        size_combo.bind('<<ComboboxSelected>>', self.change_font_settings)

        ttk.Label(theme_box, text='وزن الخط:').grid(row=6, column=0, padx=8, pady=8, sticky='e')
        self.font_weight_var = tk.StringVar(value=self.get_setting('وزن_الخط', 'عادي'))
        weight_combo = ttk.Combobox(theme_box, textvariable=self.font_weight_var,
                                    values=['عادي', 'عريض'], state='readonly', width=20)
        weight_combo.grid(row=6, column=1, padx=8, pady=8, sticky='w')
        weight_combo.bind('<<ComboboxSelected>>', self.change_font_settings)



    def change_font_settings(self, event=None):
        self.set_setting('نوع_الخط', self.font_family_var.get() or 'Tahoma')
        self.set_setting('حجم_الخط', self.font_size_var.get() or '10')
        self.set_setting('وزن_الخط', self.font_weight_var.get() or 'عادي')
        self.apply_theme(self.theme_var.get())

    def choose_text_color(self):
        from tkinter import colorchooser
        current = self.get_setting('لون_الخط', '') or '#20262b'
        chosen = colorchooser.askcolor(color=current, title='اختيار لون الخط', parent=self.root)[1]
        if chosen:
            self.set_setting('لون_الخط', chosen)
            self.apply_theme(self.theme_var.get())

    def choose_selection_color(self):
        from tkinter import colorchooser
        current = self.get_setting('لون_التحديد', '') or '#b9d7e8'
        chosen = colorchooser.askcolor(color=current, title='اختيار لون التحديد', parent=self.root)[1]
        if chosen:
            self.set_setting('لون_التحديد', chosen)
            self.apply_theme(self.theme_var.get())

    def reset_custom_colors(self):
        self.set_setting('لون_الخط', '')
        self.set_setting('لون_التحديد', '')
        self.apply_theme(self.theme_var.get())

    def save_email(self):
        email = self.email_var.get().strip()
        if '@' not in email or '.' not in email.split('@')[-1]:
            messagebox.showwarning('تنبيه', 'أدخل بريداً إلكترونياً صحيحاً.', parent=self.root)
            return
        self.set_setting('البريد_الإلكتروني', email)
        self.set_setting('بريد_الاستعادة', email)
        messagebox.showinfo('تم', 'تم حفظ البريد الإلكتروني بنجاح.', parent=self.root)

    def ensure_google_libs(self):
        """تثبيت مكتبات Google تلقائياً عند الحاجة، بدون تدخل المستخدم في الأوامر."""
        global GOOGLE_LIBS_AVAILABLE, InstalledAppFlow, Request
        if GOOGLE_LIBS_AVAILABLE:
            return True
        try:
            messagebox.showinfo('إعداد Google', 'سيتم الآن تثبيت مكونات Google اللازمة مرة واحدة. قد يستغرق ذلك قليلاً.', parent=self.root)
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--user', 'google-auth-oauthlib', 'requests'])
            from google_auth_oauthlib.flow import InstalledAppFlow as _Flow
            from google.auth.transport.requests import Request as _Request
            InstalledAppFlow = _Flow
            Request = _Request
            GOOGLE_LIBS_AVAILABLE = True
            return True
        except Exception as e:
            messagebox.showerror('Google', 'تعذر تثبيت مكونات Google تلقائياً.\n\n' + str(e), parent=self.root)
            return False

    def link_google_account(self):
        if not self.ensure_google_libs():
            return
        credentials_path = BASE_DIR / 'credentials.json'
        if not credentials_path.exists():
            messagebox.showinfo('إعداد Google',
                'لا يوجد ملف credentials.json بعد.\n\nبعد إنشاء OAuth Client من Google Cloud، ضع ملف credentials.json بجانب البرنامج ثم اضغط هذا الزر مرة أخرى.', parent=self.root)
            return
        try:
            scopes = ['openid', 'email', 'profile']
            flow = InstalledAppFlow.from_client_secrets_file(str(credentials_path), scopes=scopes)
            creds = flow.run_local_server(port=0, open_browser=True)
            import requests
            info = requests.get('https://openidconnect.googleapis.com/v1/userinfo',
                                headers={'Authorization': f'Bearer {creds.token}'}, timeout=20)
            info.raise_for_status()
            data = info.json()
            email = data.get('email', '')
            sub = data.get('sub', '')
            if not email or not sub:
                raise RuntimeError('لم يتم الحصول على هوية Google بشكل صحيح.')
            recovery = self.get_setting('البريد_الإلكتروني', '').strip().lower()
            if recovery and recovery != email.lower():
                messagebox.showerror('رفض الربط', 'البريد الذي سجلت به Google لا يطابق البريد الإلكتروني المسجل.', parent=self.root)
                return
            self.set_setting('البريد_الإلكتروني', email)
            self.set_setting('Google_Email', email)
            self.set_setting('Google_Sub', sub)
            self.email_var.set(email)
            self.google_status_var.set(email)
            messagebox.showinfo('تم الربط', f'تم ربط حساب Google بنجاح:\n{email}', parent=self.root)
        except Exception as e:
            messagebox.showerror('تعذر تسجيل الدخول إلى Google', f'{e}', parent=self.root)

    def unlink_google_account(self):
        if not self.get_setting('Google_Email', ''):
            messagebox.showinfo('Google', 'لا يوجد حساب Google مربوط.', parent=self.root)
            return
        if messagebox.askyesno('إزالة الربط', 'هل تريد إزالة ربط حساب Google؟', parent=self.root):
            self.set_setting('Google_Email', '')
            self.set_setting('Google_Sub', '')
            self.google_status_var.set('غير مربوط')
            messagebox.showinfo('تم', 'تمت إزالة ربط Google. البريد الإلكتروني بقي محفوظاً.', parent=self.root)

    def change_theme(self, event=None):
        value = self.theme_var.get()
        self.set_setting('لون_الواجهة', value)
        self.apply_theme(value)

    def change_password(self):
        old = simpledialog.askstring('تغيير كلمة المرور', 'أدخل كلمة المرور القديمة:',
                                     show='*', parent=self.root)
        if old is None:
            return
        if self.hash_password(old) != self.get_setting('كلمة_المرور'):
            messagebox.showerror('خطأ', 'كلمة المرور القديمة غير صحيحة.', parent=self.root)
            return
        new = simpledialog.askstring('تغيير كلمة المرور', 'أدخل كلمة المرور الجديدة:',
                                     show='*', parent=self.root)
        if new is None:
            return
        if len(new) < 4:
            messagebox.showwarning('تنبيه', 'كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل.', parent=self.root)
            return
        confirm = simpledialog.askstring('تغيير كلمة المرور', 'أعد إدخال كلمة المرور الجديدة:',
                                         show='*', parent=self.root)
        if confirm != new:
            messagebox.showerror('خطأ', 'كلمتا المرور غير متطابقتين.', parent=self.root)
            return
        self.set_setting('كلمة_المرور', self.hash_password(new))
        messagebox.showinfo('تم', 'تم تغيير كلمة المرور بنجاح.', parent=self.root)

    def make_tree(self, parent, columns, headings, widths=None):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        for i, c in enumerate(columns):
            tree.heading(c, text=headings[i], anchor="center")
            tree.column(c, width=(widths[i] if widths else 130), anchor="center")
        sy = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        tree.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def build_employees_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="الموظفون")

        self.ev = {k: tk.StringVar() for k in [
            "الاسم_الكامل","اسم_الأم","الجنس","تاريخ_الميلاد","رقم_الباج",
            "رقم_البطاقة_الوطنية","رقم_الهاتف","العنوان","الحالة_الزوجية","عدد_الأطفال",
            "الرقم_الوظيفي","رقم_الشعبة","الفرع_الوحدة","المسمى_الوظيفي","نوع_التعيين",
            "تاريخ_التعيين","التحصيل_الدراسي","تاريخ_التثبيت","الحالة","ملاحظات"
        ]}

        body = ttk.Frame(tab)
        body.pack(fill="both", expand=True, padx=8, pady=(4,8))
        body.columnconfigure(0, weight=3, minsize=430)
        body.columnconfigure(1, weight=7, minsize=700)
        body.rowconfigure(0, weight=1)

        # اليسار: المعلومات الشخصية فوق معلومات العمل، مع مسطرة تمرير
        left_holder = ttk.Frame(body)
        left_holder.grid(row=0, column=0, sticky="nsew", padx=(0,6))
        left_holder.rowconfigure(0, weight=1)
        left_holder.columnconfigure(0, weight=1)
        left_canvas = tk.Canvas(left_holder, highlightthickness=0, borderwidth=0)
        left_scroll = ttk.Scrollbar(left_holder, orient="vertical", command=left_canvas.yview)
        left_canvas.configure(yscrollcommand=left_scroll.set)
        left_canvas.grid(row=0,column=0,sticky="nsew")
        left_scroll.grid(row=0,column=1,sticky="ns")
        left = ttk.Frame(left_canvas)
        left_window = left_canvas.create_window((0,0), window=left, anchor="nw")
        left.columnconfigure(0, weight=1)
        left.bind("<Configure>", lambda e: left_canvas.configure(scrollregion=left_canvas.bbox("all")))
        left_canvas.bind("<Configure>", lambda e: left_canvas.itemconfigure(left_window, width=e.width))
        left_canvas.bind_all("<MouseWheel>", lambda e: left_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        personal = ttk.LabelFrame(left, text="المعلومات الشخصية", padding=8)
        personal.grid(row=0,column=0,sticky="ew",pady=(0,6))
        personal.columnconfigure(0, weight=1)
        personal.columnconfigure(1, weight=0)

        work = ttk.LabelFrame(left, text="معلومات العمل", padding=8)
        work.grid(row=1,column=0,sticky="ew",pady=(6,0))
        work.columnconfigure(0, weight=1)
        work.columnconfigure(1, weight=0)

        def add_field(parent, row, label, key, width=22, values=None):
            ttk.Label(parent, text=label).grid(row=row,column=1,padx=4,pady=4,sticky="e")
            if values is not None:
                w=ttk.Combobox(parent,textvariable=self.ev[key],values=values,state="readonly",width=width,justify="right")
            else:
                w=ttk.Entry(parent,textvariable=self.ev[key],width=width,justify="right")
            w.grid(row=row,column=0,padx=4,pady=4,sticky="ew")
            return w

        def add_date(parent,row,label,key):
            ttk.Label(parent,text=label).grid(row=row,column=1,padx=4,pady=4,sticky="e")
            box=ttk.Frame(parent)
            box.grid(row=row,column=0,padx=4,pady=4,sticky="ew")
            box.columnconfigure(0,weight=1)
            entry=ttk.Entry(box,textvariable=self.ev[key],state="readonly",justify="center")
            entry.grid(row=0,column=0,sticky="ew")
            ttk.Button(box,text="📅",width=4,command=lambda k=key: DatePicker(self.root,self.ev[k],label)).grid(row=0,column=1,padx=(4,0))
            return entry

        # المعلومات الشخصية: بالترتيب المطلوب
        add_field(personal,0,"الاسم الكامل","الاسم_الكامل",28)
        add_date(personal,1,"تاريخ الميلاد","تاريخ_الميلاد")
        add_field(personal,2,"العنوان","العنوان",28)
        add_field(personal,3,"التحصيل الدراسي","التحصيل_الدراسي",28)
        add_field(personal,4,"رقم الهاتف","رقم_الهاتف",24)
        add_field(personal,5,"رقم البطاقة الوطنية","رقم_البطاقة_الوطنية",24)
        add_field(personal,6,"اسم الأم","اسم_الأم",28)
        add_field(personal,7,"الجنس","الجنس",22,["ذكر","أنثى"])
        add_field(personal,8,"الحالة الزوجية","الحالة_الزوجية",22,["أعزب","متزوج","مطلق","أرمل"])
        add_field(personal,9,"عدد الأطفال","عدد_الأطفال",22)

        # معلومات العمل: القسم ثابت ثم الشعبة ثم الفرع/الوحدة وبقية الحقول
        ttk.Label(work,text="القسم").grid(row=0,column=1,padx=4,pady=4,sticky="e")
        ttk.Label(work,text="قسم التربية والتعليم",font=("Tahoma",9,"bold")).grid(row=0,column=0,padx=4,pady=4,sticky="w")
        ttk.Label(work,text="اسم الشعبة").grid(row=1,column=1,padx=4,pady=4,sticky="e")
        self.section_combo=ttk.Combobox(work,textvariable=self.ev["رقم_الشعبة"],state="readonly",width=25,justify="right")
        self.section_combo.grid(row=1,column=0,padx=4,pady=4,sticky="ew")
        add_field(work,2,"الفرع / الوحدة","الفرع_الوحدة",25)
        add_field(work,3,"المسمى الوظيفي","المسمى_الوظيفي",25)
        add_field(work,4,"نوع التعيين","نوع_التعيين",25,["دائمي","عقد","أجر يومي"])
        add_field(work,5,"الحالة","الحالة",25,["مثبت","غير مثبت","منقول","متقاعد","مستمر بالخدمة"])
        add_field(work,6,"الرقم الوظيفي","الرقم_الوظيفي",25)
        add_field(work,7,"رقم الباج","رقم_الباج",25)
        add_date(work,8,"تاريخ التعيين","تاريخ_التعيين")
        add_date(work,9,"تاريخ التثبيت","تاريخ_التثبيت")
        add_field(work,10,"ملاحظات","ملاحظات",25)

        # اليمين: جدول التفاصيل المطلوب وبمساطر تمرير عمودية وأفقية
        right = ttk.LabelFrame(body,text="تفاصيل الموظفين",padding=8)
        right.grid(row=0,column=1,sticky="nsew",padx=(6,0))
        right.columnconfigure(0,weight=1)

        controls=ttk.Frame(right)
        controls.pack(fill="x",pady=(0,5))
        ttk.Button(controls,text="موظف جديد",command=self.clear_employee).pack(side="right",padx=2)
        ttk.Button(controls,text="حفظ / إضافة",command=self.save_employee).pack(side="right",padx=2)
        ttk.Button(controls,text="تعديل المحدد",command=self.update_employee).pack(side="right",padx=2)
        ttk.Button(controls,text="حذف المحدد",command=self.delete_employee).pack(side="right",padx=2)
        ttk.Button(controls,text="تحديث",command=self.load_employees).pack(side="right",padx=2)

        search=ttk.Frame(right)
        search.pack(fill="x",pady=(3,5))
        ttk.Label(search,text="بحث:").pack(side="right",padx=3)
        self.emp_search=tk.StringVar()
        se=ttk.Entry(search,textvariable=self.emp_search,width=25,justify="right")
        se.pack(side="right",padx=3,fill="x",expand=True)
        se.bind("<KeyRelease>",lambda e:self.load_employees())
        ttk.Label(search,text="الشعبة:").pack(side="right",padx=(8,2))
        self.emp_dept_filter=tk.StringVar(value="الكل")
        self.emp_dept_cb=ttk.Combobox(search,textvariable=self.emp_dept_filter,state="readonly",width=18)
        self.emp_dept_cb.pack(side="right",padx=2)
        self.emp_dept_cb.bind("<<ComboboxSelected>>",lambda e:self.load_employees())
        ttk.Label(search,text="الحالة:").pack(side="right",padx=(8,2))
        self.emp_status_filter=tk.StringVar(value="الكل")
        self.emp_status_cb=ttk.Combobox(search,textvariable=self.emp_status_filter,values=["الكل","مثبت","غير مثبت","منقول","متقاعد","مستمر بالخدمة"],state="readonly",width=14)
        self.emp_status_cb.pack(side="right",padx=2)
        self.emp_status_cb.bind("<<ComboboxSelected>>",lambda e:self.load_employees())

        self.emp_tree=self.make_tree(right,
            ("serial","name","badge","department","section","unit","title","status","job","phone","national","hire","confirm"),
            ["تسلسل","الاسم الكامل","رقم الباج","القسم","الشعبة","الفرع / الوحدة","المسمى الوظيفي","الحالة","الرقم الوظيفي","رقم الهاتف","البطاقة الوطنية","تاريخ التعيين","تاريخ التثبيت"],
            [65,240,110,170,170,180,180,110,110,130,150,120,120])
        self.emp_tree.bind("<<TreeviewSelect>>",self.on_employee_select)

    def sections(self):
        return [(r[0], r[1]) for r in self.q("SELECT رقم_الشعبة,اسم_الشعبة FROM الشعب ORDER BY رقم_الشعبة")]

    def refresh_sections(self):
        vals = [n for i, n in self.sections()]
        self.section_combo["values"] = vals
        if hasattr(self, "emp_dept_cb"):
            self.emp_dept_cb["values"] = ["الكل"] + vals
            if self.emp_dept_filter.get() not in (["الكل"] + vals):
                self.emp_dept_filter.set("الكل")

    def section_id(self):
        s = self.ev["رقم_الشعبة"].get().strip()
        if not s:
            return None
        row = self.q("SELECT رقم_الشعبة FROM الشعب WHERE اسم_الشعبة=?", (s,)).fetchone()
        return row[0] if row else None

    def clear_employee(self):
        self.selected_employee_id = None
        for v in self.ev.values():
            v.set("")
        self.ev["الجنس"].set("ذكر")
        self.ev["نوع_التعيين"].set("دائمي")
        self.ev["الحالة"].set("مثبت")
        self.refresh_sections()

    def _valid_date_value(self, value, allow_year_only=True):
        value=(value or "").strip()
        if not value:
            return True
        for fmt in ("%Y-%m-%d","%d\\%m\\%Y","%d/%m/%Y"):
            try:
                datetime.strptime(value,fmt)
                return True
            except Exception:
                pass
        if allow_year_only and value.isdigit() and len(value)==4:
            try:
                datetime.strptime(value,"%Y")
                return True
            except Exception:
                pass
        return False

    def _validate_employee_dates(self):
        checks=[("تاريخ الميلاد",self.ev["تاريخ_الميلاد"].get()),
                ("تاريخ التعيين",self.ev["تاريخ_التعيين"].get()),
                ("تاريخ التثبيت",self.ev["تاريخ_التثبيت"].get())]
        for label,value in checks:
            if not self._valid_date_value(value):
                messagebox.showwarning("تاريخ غير صحيح",f"{label} غير صحيح. استخدم زر التقويم 📅 لاختيار التاريخ.")
                return False
        return True

    def save_employee(self):
        name = self.ev["الاسم_الكامل"].get().strip()
        if not name:
            messagebox.showwarning("تنبيه", "أدخل الاسم الكامل.")
            return
        if not self._validate_employee_dates():
            return
        try:
            self.q("""INSERT INTO المنتسبون
            (الرقم_الوظيفي,الاسم_الكامل,اسم_الأم,الجنس,تاريخ_الميلاد,رقم_الهاتف,العنوان,رقم_القسم,
             المسمى_الوظيفي,نوع_التعيين,تاريخ_التعيين,التحصيل_الدراسي,الحالة_الزوجية,تاريخ_التثبيت,الحالة,ملاحظات,
             رقم_الشعبة,الفرع_الوحدة,رقم_الباج,رقم_البطاقة_الوطنية,عدد_الأطفال)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                self.ev["الرقم_الوظيفي"].get() or None,
                name,
                self.ev["اسم_الأم"].get(),
                self.ev["الجنس"].get(),
                self.ev["تاريخ_الميلاد"].get(),
                self.ev["رقم_الهاتف"].get(),
                self.ev["العنوان"].get(),
                None,
                self.ev["المسمى_الوظيفي"].get(),
                self.ev["نوع_التعيين"].get(),
                self.ev["تاريخ_التعيين"].get(),
                self.ev["التحصيل_الدراسي"].get(),
                self.ev["الحالة_الزوجية"].get(),
                self.ev["تاريخ_التثبيت"].get(),
                self.ev["الحالة"].get(),
                self.ev["ملاحظات"].get(),
                self.section_id(),
                self.ev["الفرع_الوحدة"].get(),
                self.ev["رقم_الباج"].get(),
                self.ev["رقم_البطاقة_الوطنية"].get(),
                int(self.ev["عدد_الأطفال"].get()) if self.ev["عدد_الأطفال"].get().strip().isdigit() else None
            ))
            self.commit()
            self.load_employees()
            self.clear_employee()
            messagebox.showinfo("تم", "تمت إضافة المنتسب.")
        except sqlite3.IntegrityError:
            messagebox.showerror("خطأ", "الرقم الوظيفي مستخدم مسبقاً.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def update_employee(self):
        if not self.selected_employee_id:
            messagebox.showwarning("تنبيه", "حدد موظفاً أولاً.")
            return
        if not self._validate_employee_dates():
            return
        try:
            self.q("""UPDATE المنتسبون SET الرقم_الوظيفي=?,الاسم_الكامل=?,اسم_الأم=?,الجنس=?,تاريخ_الميلاد=?,
            رقم_الهاتف=?,العنوان=?,رقم_القسم=?,المسمى_الوظيفي=?,نوع_التعيين=?,تاريخ_التعيين=?,
            التحصيل_الدراسي=?,الحالة_الزوجية=?,تاريخ_التثبيت=?,الحالة=?,ملاحظات=?,
            رقم_الشعبة=?,الفرع_الوحدة=?,رقم_الباج=?,رقم_البطاقة_الوطنية=?,عدد_الأطفال=? WHERE رقم_المنتسب=?""",
            (
                self.ev["الرقم_الوظيفي"].get() or None,
                self.ev["الاسم_الكامل"].get(),
                self.ev["اسم_الأم"].get(),
                self.ev["الجنس"].get(),
                self.ev["تاريخ_الميلاد"].get(),
                self.ev["رقم_الهاتف"].get(),
                self.ev["العنوان"].get(),
                None,
                self.ev["المسمى_الوظيفي"].get(),
                self.ev["نوع_التعيين"].get(),
                self.ev["تاريخ_التعيين"].get(),
                self.ev["التحصيل_الدراسي"].get(),
                self.ev["الحالة_الزوجية"].get(),
                self.ev["تاريخ_التثبيت"].get(),
                self.ev["الحالة"].get(),
                self.ev["ملاحظات"].get(),
                self.section_id(),
                self.ev["الفرع_الوحدة"].get(),
                self.ev["رقم_الباج"].get(),
                self.ev["رقم_البطاقة_الوطنية"].get(),
                int(self.ev["عدد_الأطفال"].get()) if self.ev["عدد_الأطفال"].get().strip().isdigit() else None,
                self.selected_employee_id
            ))
            self.commit()
            self.load_employees()
            messagebox.showinfo("تم", "تم تعديل البيانات.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def delete_employee(self):
        if not self.selected_employee_id:
            messagebox.showwarning("تنبيه", "حدد منتسباً أولاً.")
            return
        if not messagebox.askyesno("تأكيد", "هل تريد حذف المنتسب؟"):
            return
        try:
            self.q("DELETE FROM المنتسبون WHERE رقم_المنتسب=?", (self.selected_employee_id,))
            self.commit()
            self.load_employees()
            self.clear_employee()
        except sqlite3.IntegrityError:
            messagebox.showerror("لا يمكن الحذف", "لدى هذا المنتسب سجلات مرتبطة. احذف السجلات المرتبطة أولاً.")

    def on_employee_select(self, event=None):
        sel = self.emp_tree.selection()
        if not sel:
            return
        self.selected_employee_id = int(sel[0])
        row = self.q("SELECT * FROM المنتسبون WHERE رقم_المنتسب=?", (self.selected_employee_id,)).fetchone()
        if not row:
            return
        cols = [d[0] for d in self.q("SELECT * FROM المنتسبون LIMIT 0").description]
        d = dict(zip(cols,row))
        for k,v in self.ev.items():
            v.set("" if d.get(k) is None else str(d[k]))
        sec=d.get("رقم_الشعبة")
        if sec:
            name=self.q("SELECT اسم_الشعبة FROM الشعب WHERE رقم_الشعبة=?",(sec,)).fetchone()
            self.ev["رقم_الشعبة"].set(name[0] if name else "")

    def load_employees(self):
        self.refresh_sections()
        for x in self.emp_tree.get_children():
            self.emp_tree.delete(x)
        s = self.emp_search.get().strip()
        sql = """SELECT م.رقم_المنتسب,م.الاسم_الكامل,COALESCE(م.رقم_الباج,''),
                 'قسم التربية والتعليم',COALESCE(ش.اسم_الشعبة,''),COALESCE(م.الفرع_الوحدة,''),
                 COALESCE(م.المسمى_الوظيفي,''),COALESCE(م.الحالة,''),COALESCE(م.الرقم_الوظيفي,''),
                 COALESCE(م.رقم_الهاتف,''),COALESCE(م.رقم_البطاقة_الوطنية,''),
                 COALESCE(م.تاريخ_التعيين,''),COALESCE(م.تاريخ_التثبيت,'')
                 FROM المنتسبون م LEFT JOIN الشعب ش ON ش.رقم_الشعبة=م.رقم_الشعبة"""
        conditions=[]; params=[]
        if s:
            conditions.append("""(م.الاسم_الكامل LIKE ? OR م.الرقم_الوظيفي LIKE ? OR م.رقم_الهاتف LIKE ?
                               OR م.المسمى_الوظيفي LIKE ? OR م.رقم_الباج LIKE ? OR م.رقم_البطاقة_الوطنية LIKE ?)""")
            params += [f"%{s}%"] * 6
        dept_filter = getattr(self,"emp_dept_filter",tk.StringVar(value="الكل")).get()
        if dept_filter and dept_filter != "الكل":
            row=self.q("SELECT رقم_الشعبة FROM الشعب WHERE اسم_الشعبة=?",(dept_filter,)).fetchone()
            if row:
                conditions.append("م.رقم_الشعبة=?"); params.append(row[0])
        status_filter=getattr(self,"emp_status_filter",tk.StringVar(value="الكل")).get()
        if status_filter and status_filter != "الكل":
            conditions.append("م.الحالة=?"); params.append(status_filter)
        if conditions: sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY م.رقم_المنتسب"
        for serial, r in enumerate(self.q(sql,params), start=1):
            # الرقم الداخلي لا يظهر للمستخدم؛ أول عمود هو تسلسل العرض.
            values=[serial]+list(r[1:])
            self.emp_tree.insert("", "end", iid=str(r[0]), values=values)

    def employee_choices(self):
        # عرض الاسم أولاً ثم الرقم لتسهيل الاختيار
        return [(r[0], f"{r[1]} - {r[0]}") for r in self.q(
            "SELECT رقم_المنتسب,الاسم_الكامل FROM المنتسبون ORDER BY الاسم_الكامل"
        )]

    def setup_employee_combo_search(self, combo):
        """قائمة منتسبين قابلة للكتابة والبحث، مع تصفية فورية أثناء الكتابة."""
        combo._all_employee_values = [x[1] for x in self.employee_choices()]
        combo["values"] = combo._all_employee_values
        if getattr(combo, "_employee_search_bound", False):
            return combo
        def on_key(event=None):
            typed = combo.get().strip()
            all_values = combo._all_employee_values
            vals = all_values if not typed else [v for v in all_values if typed.casefold() in v.casefold()]
            combo["values"] = vals
            if vals and typed:
                combo.event_generate("<Down>")
        combo.bind("<KeyRelease>", on_key, add="+")
        combo.bind("<Button-1>", lambda e: combo.configure(values=combo._all_employee_values), add="+")
        combo._employee_search_bound = True
        return combo

    def generic_record_tab(self, title, table, fields, display_cols, headings, idcol):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text=title)
        form = ttk.LabelFrame(tab, text=f"بيانات {title}", padding=8)
        form.pack(fill="x", padx=8, pady=8)

        # ألوان خفيفة لتمييز النماذج بصرياً، خصوصاً الغيابات.
        style = ttk.Style()
        if title == "الغيابات":
            style.configure("Absence.TEntry", fieldbackground="#ffe4e4")
            style.configure("Absence.TCombobox", fieldbackground="#ffe4e4")
            entry_style = "Absence.TEntry"
            combo_style = "Absence.TCombobox"
        else:
            entry_style = "TEntry"
            combo_style = "TCombobox"

        vars = {k: tk.StringVar() for k in fields}
        setattr(self, f"v_{table}", vars)

        # حقول مدمجة وواضحة: تسمية مظللة + حقل ثابت العرض، بدون تمدد مبالغ فيه.
        label_style = "FieldLabel.TLabel"
        style.configure(label_style, background="#edf3f8", foreground="#27465d", padding=(7,4), font=("Tahoma", 9, "bold"))
        for i, k in enumerate(fields):
            r = i // 4
            c = (i % 4) * 2
            ttk.Label(form, text=("الاسم" if k == "رقم_المنتسب" else k.replace("_", " ")), style=label_style).grid(row=r, column=c, padx=(3,2), pady=3, sticky="e")
            if k == "رقم_المنتسب":
                cb = ttk.Combobox(form, textvariable=vars[k], state="normal", width=24, justify="right", style=combo_style)
                cb.grid(row=r, column=c+1, padx=(2,7), pady=3, sticky="w")
                self.setup_employee_combo_search(cb)
                setattr(self, f"cb_{table}", cb)
            elif "تاريخ" in k or k == "التاريخ":
                box = ttk.Frame(form)
                box.grid(row=r, column=c+1, padx=(2,7), pady=3, sticky="w")
                ttk.Entry(box, textvariable=vars[k], state="readonly", width=14, justify="center", style=entry_style).grid(row=0, column=0)
                ttk.Button(box, text="📅", width=3, command=lambda key=k, label=k.replace("_", " "): DatePicker(self.root, vars[key], label)).grid(row=0, column=1, padx=(3,0))
            else:
                ttk.Entry(form, textvariable=vars[k], width=18, justify="right", style=entry_style).grid(
                    row=r, column=c+1, padx=(2,7), pady=3, sticky="w"
                )
        for c in range(8):
            form.columnconfigure(c, weight=0)

        b = ttk.Frame(tab)
        b.pack(fill="x", padx=8)
        ttk.Button(b, text="سجل جديد", command=lambda t=table: self.clear_record(t)).pack(side="right", padx=3)
        ttk.Button(b, text="حفظ / إضافة", command=lambda t=table: self.save_record(t)).pack(side="right", padx=3)
        ttk.Button(b, text="تعديل المحدد", command=lambda t=table: self.update_record(t)).pack(side="right", padx=3)
        ttk.Button(b, text="حذف المحدد", command=lambda t=table: self.delete_record(t)).pack(side="right", padx=3)

        # بحث مستقل لكل سجل
        search_bar = ttk.Frame(tab)
        search_bar.pack(fill="x", padx=8, pady=(2, 0))
        ttk.Label(search_bar, text="بحث باسم المنتسب أو داخل السجلات:").pack(side="right", padx=4)
        search_var = tk.StringVar()
        setattr(self, f"search_{table}", search_var)
        search_entry = ttk.Entry(search_bar, textvariable=search_var, width=32, justify="right")
        search_entry.pack(side="right", padx=4)
        search_entry.bind("<KeyRelease>", lambda e, t=table: self.load_table(t))
        search_entry.bind("<Return>", lambda e, t=table: self.load_table(t))
        ttk.Button(search_bar, text="بحث", command=lambda t=table: self.load_table(t)).pack(side="right", padx=3)
        ttk.Button(search_bar, text="مسح البحث", command=lambda t=table: self.clear_table_search(t)).pack(side="right", padx=3)

        tree_columns = tuple([idcol, "اسم_المنتسب"] + display_cols)
        tree_headings = [idcol, "الاسم"] + headings
        tree = self.make_tree(tab, tree_columns, tree_headings,
                              [70, 220] + [150] * len(display_cols))
        setattr(self, f"tree_{table}", tree)
        tree.bind("<<TreeviewSelect>>", lambda e, t=table: self.on_record_select(t))

    def build_leaves_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="الإجازات")

        form = ttk.LabelFrame(tab, text="بيانات الإجازة", padding=8)
        form.pack(fill="x", padx=8, pady=8)

        # ألوان الإجازات: الاعتيادية وباقي الأنواع بالسمائي، والزمنية بالأخضر الفاتح.
        style = ttk.Style()
        style.configure("LeaveSky.TEntry", fieldbackground="#dff3ff")
        style.configure("LeaveSky.TCombobox", fieldbackground="#dff3ff")
        style.configure("LeaveWhite.TEntry", fieldbackground="#ffffff")
        style.configure("LeaveWhite.TCombobox", fieldbackground="#ffffff")
        style.configure("LeaveTime.TEntry", fieldbackground="#e2f7e2")
        style.configure("LeaveTime.TCombobox", fieldbackground="#e2f7e2")
        fields = ["رقم_المنتسب","نوع_الإجازة","من_تاريخ","إلى_تاريخ","عدد_الأيام","تاريخ_الإجازة","من_الساعة","إلى_الساعة","عدد_الساعات","سبب_الإجازة","حالة_الإجازة","ملاحظات"]
        vars = {k: tk.StringVar() for k in fields}
        self.v_الإجازات = vars

        # مجموعة واضحة للبيانات الأساسية، منفصلة بصرياً عن بقية حقول الإجازة.
        basic = ttk.LabelFrame(form, text="البيانات الأساسية", padding=(10,6))
        basic.grid(row=0, column=0, columnspan=8, sticky="ew", padx=2, pady=(0,5))
        # ترتيب عربي واضح: الاسم في اليمين، نوع الإجازة في اليسار، وبينهما فاصل واضح.
        for c in range(8):
            basic.columnconfigure(c, weight=0)
        basic.columnconfigure(1, weight=0)
        basic.columnconfigure(5, weight=0)
        lbl = "FieldLabel.TLabel"

        # البيانات الأساسية — نجمع الاسم ونوع الإجازة في الجهة اليمنى، مع ترك مساحة مريحة في اليسار.
        # تسميات مظللة مع رموز واضحة لتسهيل قراءة الحقول.
        label_style = "LeaveFieldLabel.TLabel"
        style.configure(label_style, background="#e7eef5", foreground="#23445d", padding=(9,5), font=("Tahoma", 10, "bold"), relief="solid", borderwidth=1)

        # الاسم — أقصى اليمين وبحقل أكبر
        ttk.Label(basic, text="👤  الاسم", style=label_style).grid(row=0,column=7,padx=(2,5),pady=6,sticky="e")
        cb_emp = ttk.Combobox(basic, textvariable=vars["رقم_المنتسب"], state="normal", width=28, justify="right", style="LeaveWhite.TCombobox")
        cb_emp.grid(row=0,column=6,padx=(0,12),pady=6,sticky="w")
        self.cb_الإجازات = self.setup_employee_combo_search(cb_emp)

        # فاصل واضح بين الاسم ونوع الإجازة
        ttk.Separator(basic, orient="vertical").grid(row=0,column=5,rowspan=1,sticky="ns",padx=12,pady=4)

        # نوع الإجازة — إلى يسار الاسم لكن ما يزال ضمن الجهة اليمنى
        types = ["اعتيادية", "إجازة زمنية", "تعويضية", "سفر", "مرضية", "أمومة"]
        ttk.Label(basic, text="📋  نوع الإجازة", style=label_style).grid(row=0,column=4,padx=(5,5),pady=6,sticky="e")
        cb_type = ttk.Combobox(basic, textvariable=vars["نوع_الإجازة"], values=types, state="readonly", width=20, style="LeaveSky.TCombobox")
        cb_type.grid(row=0,column=3,padx=(0,8),pady=6,sticky="w")
        cb_type.bind("<<ComboboxSelected>>", lambda e: self.on_leave_type_change())
        self.cb_نوع_الإجازة = cb_type
        vars["من_تاريخ"].trace_add("write", self.calc_leave_days)
        vars["إلى_تاريخ"].trace_add("write", self.calc_leave_days)
        vars["من_الساعة"].trace_add("write", self.calc_leave_hours)
        vars["إلى_الساعة"].trace_add("write", self.calc_leave_hours)

        # خط فاصل واضح بين البيانات الأساسية وبقية تفاصيل الإجازة.
        ttk.Separator(form, orient="horizontal").grid(row=1,column=0,columnspan=8,sticky="ew",pady=(2,2))
        ttk.Label(form, text="تفاصيل الإجازة", style="FieldLabel.TLabel").grid(row=2,column=0,columnspan=8,sticky="e",padx=2,pady=(2,3))

        # الحقول الرئيسية مرتبة بمجموعات متناسقة وبدون فراغات كبيرة
        self.leave_normal_frame = ttk.Frame(form)
        self.leave_normal_frame.grid(row=3,column=0,columnspan=8,sticky="ew",padx=2)
        for c in range(8): self.leave_normal_frame.columnconfigure(c, weight=0)
        self.leave_normal_frame.columnconfigure(1, weight=1)
        self.leave_normal_frame.columnconfigure(5, weight=1)
        ttk.Label(self.leave_normal_frame,text="من تاريخ").grid(row=0,column=6,padx=(4,2),pady=4,sticky="e")
        ttk.Entry(self.leave_normal_frame,textvariable=vars["من_تاريخ"],state="readonly",width=16,justify="center",style="LeaveSky.TEntry").grid(row=0,column=5,padx=2,pady=4,sticky="ew")
        ttk.Button(self.leave_normal_frame,text="📅",width=3,command=lambda: DatePicker(self.root,vars["من_تاريخ"],"من تاريخ")).grid(row=0,column=4,padx=2,pady=4)
        ttk.Label(self.leave_normal_frame,text="إلى تاريخ").grid(row=0,column=3,padx=(14,2),pady=4,sticky="e")
        ttk.Entry(self.leave_normal_frame,textvariable=vars["إلى_تاريخ"],state="readonly",width=16,justify="center",style="LeaveSky.TEntry").grid(row=0,column=1,padx=2,pady=4,sticky="ew")
        ttk.Button(self.leave_normal_frame,text="📅",width=3,command=lambda: DatePicker(self.root,vars["إلى_تاريخ"],"إلى تاريخ")).grid(row=0,column=0,padx=2,pady=4)
        ttk.Label(self.leave_normal_frame,text="عدد الأيام").grid(row=1,column=6,padx=(4,2),pady=4,sticky="e")
        ttk.Entry(self.leave_normal_frame,textvariable=vars["عدد_الأيام"],state="readonly",width=16,justify="center",style="LeaveSky.TEntry").grid(row=1,column=5,padx=2,pady=4,sticky="ew")

        self.leave_time_frame = ttk.Frame(form)
        self.leave_time_frame.grid(row=4,column=0,columnspan=8,sticky="ew",padx=2)
        for c in range(8): self.leave_time_frame.columnconfigure(c, weight=0)
        self.leave_time_frame.columnconfigure(1, weight=1)
        self.leave_time_frame.columnconfigure(5, weight=1)
        ttk.Label(self.leave_time_frame,text="التاريخ").grid(row=0,column=6,padx=(4,2),pady=4,sticky="e")
        ttk.Entry(self.leave_time_frame,textvariable=vars["تاريخ_الإجازة"],state="readonly",width=16,justify="center",style="LeaveTime.TEntry").grid(row=0,column=5,padx=2,pady=4,sticky="ew")
        ttk.Button(self.leave_time_frame,text="📅",width=3,command=lambda: DatePicker(self.root,vars["تاريخ_الإجازة"],"تاريخ الإجازة")).grid(row=0,column=4,padx=2,pady=4)
        ttk.Label(self.leave_time_frame,text="من الساعة").grid(row=0,column=3,padx=(14,2),pady=4,sticky="e")
        cb_from=ttk.Combobox(self.leave_time_frame,textvariable=vars["من_الساعة"],values=self.time_choices(),state="normal",width=12,justify="center",style="LeaveTime.TCombobox")
        cb_from.grid(row=0,column=1,padx=2,pady=4,sticky="ew")
        ttk.Label(self.leave_time_frame,text="إلى الساعة").grid(row=1,column=3,padx=(14,2),pady=4,sticky="e")
        cb_to=ttk.Combobox(self.leave_time_frame,textvariable=vars["إلى_الساعة"],values=self.time_choices(),state="normal",width=12,justify="center",style="LeaveTime.TCombobox")
        cb_to.grid(row=1,column=1,padx=2,pady=4,sticky="ew")
        cb_from.bind("<<ComboboxSelected>>",lambda e:self.calc_leave_hours())
        cb_to.bind("<<ComboboxSelected>>",lambda e:self.calc_leave_hours())
        ttk.Label(self.leave_time_frame,text="عدد الساعات").grid(row=1,column=6,padx=(4,2),pady=4,sticky="e")
        ttk.Entry(self.leave_time_frame,textvariable=vars["عدد_الساعات"],state="readonly",width=16,justify="center",style="LeaveTime.TEntry").grid(row=1,column=5,padx=2,pady=4,sticky="ew")
        self.cb_leave_from_time=cb_from; self.cb_leave_to_time=cb_to
        self.leave_color_widgets = [cb_emp, cb_type, cb_from, cb_to]

        ttk.Label(form,text="سبب الإجازة",style="FieldLabel.TLabel").grid(row=5,column=6,padx=(4,2),pady=4,sticky="e")
        ttk.Entry(form,textvariable=vars["سبب_الإجازة"],width=24,justify="right",style="LeaveSky.TEntry").grid(row=5,column=5,padx=2,pady=4,sticky="ew")
        ttk.Label(form,text="الحالة",style="FieldLabel.TLabel").grid(row=5,column=3,padx=(14,2),pady=4,sticky="e")
        ttk.Combobox(form,textvariable=vars["حالة_الإجازة"],values=["مقبولة","مرفوضة","قيد الانتظار"],state="readonly",width=14,style="LeaveSky.TCombobox").grid(row=5,column=1,padx=2,pady=4,sticky="ew")
        ttk.Label(form,text="ملاحظات",style="FieldLabel.TLabel").grid(row=6,column=6,padx=(4,2),pady=4,sticky="e")
        ttk.Entry(form,textvariable=vars["ملاحظات"],width=24,justify="right",style="LeaveSky.TEntry").grid(row=6,column=5,padx=2,pady=4,sticky="ew")
        for c in range(8): form.columnconfigure(c,weight=0)
        form.columnconfigure(1,weight=1); form.columnconfigure(5,weight=1); form.columnconfigure(7,weight=1)
        self.leave_color_widgets = self._collect_leave_color_widgets(form)
        self.leave_employee_widget = cb_emp
        self.apply_leave_color()
        try:
            cb_emp.configure(style="LeaveWhite.TCombobox")
        except Exception:
            pass

        b=ttk.Frame(tab); b.pack(fill="x",padx=8)
        ttk.Button(b,text="سجل جديد",command=self.clear_leave).pack(side="right",padx=3)
        ttk.Button(b,text="حفظ / إضافة",command=self.save_leave).pack(side="right",padx=3)
        ttk.Button(b,text="تعديل المحدد",command=self.update_leave).pack(side="right",padx=3)
        ttk.Button(b,text="حذف المحدد",command=self.delete_leave).pack(side="right",padx=3)

        search_bar=ttk.Frame(tab); search_bar.pack(fill="x",padx=8,pady=(2,0))
        ttk.Label(search_bar,text="بحث بالاسم أو داخل السجلات:").pack(side="right",padx=4)
        self.search_الإجازات=tk.StringVar()
        ent=ttk.Entry(search_bar,textvariable=self.search_الإجازات,width=32,justify="right"); ent.pack(side="right",padx=4)
        ent.bind("<KeyRelease>",lambda e:self.load_table("الإجازات")); ent.bind("<Return>",lambda e:self.load_table("الإجازات"))
        ttk.Button(search_bar,text="بحث",command=lambda:self.load_table("الإجازات")).pack(side="right",padx=3)
        ttk.Button(search_bar,text="مسح البحث",command=lambda:self.clear_table_search("الإجازات")).pack(side="right",padx=3)

        frame=ttk.Frame(tab); frame.pack(fill="both",expand=True,padx=8,pady=5)
        columns=("رقم_الإجازة","اسم_المنتسب","نوع_الإجازة","من_تاريخ","إلى_تاريخ","عدد_الأيام","تاريخ_الإجازة","من_الساعة","إلى_الساعة","عدد_الساعات","حالة_الإجازة")
        self.tree_الإجازات=ttk.Treeview(frame,columns=columns,show="headings")
        heads=["رقم الإجازة","الاسم","نوع الإجازة","من تاريخ","إلى تاريخ","الأيام","تاريخ الإجازة","من الساعة","إلى الساعة","الساعات","الحالة"]
        widths=[80,190,120,110,110,70,110,90,90,100,100]
        for col,head,w in zip(columns,heads,widths):
            self.tree_الإجازات.heading(col,text=head,anchor="center"); self.tree_الإجازات.column(col,width=w,minwidth=70,anchor="center")
        sy=ttk.Scrollbar(frame,orient="vertical",command=self.tree_الإجازات.yview); sx=ttk.Scrollbar(frame,orient="horizontal",command=self.tree_الإجازات.xview)
        self.tree_الإجازات.configure(yscrollcommand=sy.set,xscrollcommand=sx.set)
        self.tree_الإجازات.grid(row=0,column=0,sticky="nsew"); sy.grid(row=0,column=1,sticky="ns"); sx.grid(row=1,column=0,sticky="ew")
        frame.rowconfigure(0,weight=1); frame.columnconfigure(0,weight=1)
        self.tree_الإجازات.bind("<<TreeviewSelect>>",self.on_leave_select)
        self.toggle_leave_mode()

    def time_choices(self):
        vals=[]
        for ap in ("ص", "م"):
            for h in range(1,13):
                for m in (0,30):
                    vals.append(f"{h:02d}:{m:02d} {ap}")
        return vals

    def parse_display_time(self, value):
        value=(value or "").strip()
        value=value.replace("صباحاً","ص").replace("صباحا","ص").replace("مساءً","م").replace("مساءا","م")
        value=value.replace("AM","ص").replace("PM","م").replace("am","ص").replace("pm","م")
        value=value.replace("ص ","ص").replace("م ","م")
        try:
            ap=None
            if value.endswith("ص") or value.endswith("م"):
                ap=value[-1]; hm=value[:-1].strip()
                if ":" in hm:
                    h,m=map(int,hm.split(":",1))
                else:
                    h=int(hm); m=0
                if not (1<=h<=12 and 0<=m<=59): return None
                h24=(0 if h==12 else h) if ap=="ص" else (12 if h==12 else h+12)
                return h24*60+m
            h,m=map(int,value.split(":",1))
            if 0<=h<=23 and 0<=m<=59: return h*60+m
        except Exception:
            pass
        return None

    def _collect_leave_color_widgets(self, parent):
        widgets=[]
        for child in parent.winfo_children():
            if isinstance(child, (ttk.Entry, ttk.Combobox)):
                widgets.append(child)
            widgets.extend(self._collect_leave_color_widgets(child))
        return widgets

    def apply_leave_color(self):
        # السمائي لكل الأنواع العادية، والأخضر الفاتح للإجازة الزمنية.
        is_time=self.v_الإجازات["نوع_الإجازة"].get().strip()=="إجازة زمنية"
        prefix="LeaveTime" if is_time else "LeaveSky"
        for w in getattr(self, "leave_color_widgets", []):
            try:
                if getattr(self, "leave_employee_widget", None) is w:
                    w.configure(style="LeaveWhite.TCombobox")
                else:
                    w.configure(style=prefix + (".TCombobox" if isinstance(w, ttk.Combobox) else ".TEntry"))
            except Exception:
                pass

    def on_leave_type_change(self):
        self.apply_leave_color()
        self.toggle_leave_mode()

    def toggle_leave_mode(self):
        self.apply_leave_color()
        is_time=self.v_الإجازات["نوع_الإجازة"].get().strip()=="إجازة زمنية"
        if is_time:
            self.leave_normal_frame.grid_remove(); self.leave_time_frame.grid()
            self.v_الإجازات["من_تاريخ"].set(""); self.v_الإجازات["إلى_تاريخ"].set(""); self.v_الإجازات["عدد_الأيام"].set("")
        else:
            self.leave_time_frame.grid_remove(); self.leave_normal_frame.grid()
            self.v_الإجازات["تاريخ_الإجازة"].set(""); self.v_الإجازات["من_الساعة"].set(""); self.v_الإجازات["إلى_الساعة"].set(""); self.v_الإجازات["عدد_الساعات"].set("")
            self.calc_leave_days()

    def parse_leave_date(self,value):
        value=(value or "").strip()
        for fmt in ("%Y-%m-%d", r"%d\%m\%Y", "%d/%m/%Y"):
            try: return datetime.strptime(value,fmt)
            except Exception: pass
        return None

    def calc_leave_days(self,event=None,*args):
        if self.v_الإجازات["نوع_الإجازة"].get().strip()=="إجازة زمنية": return
        a=self.parse_leave_date(self.v_الإجازات["من_تاريخ"].get()); b=self.parse_leave_date(self.v_الإجازات["إلى_تاريخ"].get())
        self.v_الإجازات["عدد_الأيام"].set(str((b-a).days+1) if a and b and b>=a else "")

    def calc_leave_hours(self,event=None,*args):
        a=self.parse_display_time(self.v_الإجازات["من_الساعة"].get())
        b=self.parse_display_time(self.v_الإجازات["إلى_الساعة"].get())
        if a is None or b is None or b<=a:
            self.v_الإجازات["عدد_الساعات"].set("")
            return
        mins=b-a; h,m=divmod(mins,60)
        self.v_الإجازات["عدد_الساعات"].set(f"{h} ساعة و {m} دقيقة" if m else f"{h} ساعة")

    def clear_leave(self):
        for v in self.v_الإجازات.values(): v.set("")
        self.v_الإجازات["حالة_الإجازة"].set("مقبولة"); self.setup_employee_combo_search(self.cb_الإجازات)
        self.selected_leave_id=None; self.toggle_leave_mode()

    def leave_form_data(self):
        v=self.v_الإجازات
        if not v["رقم_المنتسب"].get().strip(): raise ValueError("اختر المنتسب.")
        emp_id=self.emp_id_from_text(v["رقم_المنتسب"].get())
        if not emp_id: raise ValueError("المنتسب غير صحيح.")
        typ=v["نوع_الإجازة"].get().strip()
        if not typ: raise ValueError("اختر نوع الإجازة.")
        if typ=="إجازة زمنية":
            date=v["تاريخ_الإجازة"].get().strip()
            if not self.parse_leave_date(date): raise ValueError("اختر تاريخ الإجازة من الرزنامة.")
            self.calc_leave_hours()
            if not v["عدد_الساعات"].get(): raise ValueError("حدد الوقت بشكل صحيح: وقت الانتهاء يجب أن يكون بعد وقت البدء.")
            from_date=to_date=date; days=1; start=v["من_الساعة"].get().strip(); end=v["إلى_الساعة"].get().strip(); hours=v["عدد_الساعات"].get().strip()
        else:
            from_date=v["من_تاريخ"].get().strip(); to_date=v["إلى_تاريخ"].get().strip(); a=self.parse_leave_date(from_date); b=self.parse_leave_date(to_date)
            if not a or not b or b<a: raise ValueError("حدد تاريخي البداية والنهاية بشكل صحيح من الرزنامة.")
            self.calc_leave_days(); days=int(v["عدد_الأيام"].get()); date=start=end=hours=""
        return {"رقم_المنتسب":emp_id,"نوع_الإجازة":typ,"من_تاريخ":from_date,"إلى_تاريخ":to_date,"عدد_الأيام":days,"تاريخ_الإجازة":date,"من_الساعة":start,"إلى_الساعة":end,"عدد_الساعات":hours,"سبب_الإجازة":v["سبب_الإجازة"].get().strip() or None,"حالة_الإجازة":v["حالة_الإجازة"].get().strip() or "مقبولة","ملاحظات":v["ملاحظات"].get().strip() or None}

    def save_leave(self):
        try:
            data=self.leave_form_data(); cols=list(data); vals=[data[c] for c in cols]; qs=",".join("?" for _ in cols)
            self.q(f'INSERT INTO "الإجازات" ({",".join(cols)}) VALUES ({qs})',vals); self.commit(); self.load_table("الإجازات"); self.clear_leave(); messagebox.showinfo("تم","تم حفظ الإجازة.")
        except Exception as e: messagebox.showerror("خطأ",str(e))

    def update_leave(self):
        if not self.selected_leave_id: messagebox.showwarning("تنبيه","حدد سجلاً أولاً."); return
        try:
            data=self.leave_form_data(); sets=",".join(f'"{c}"=?' for c in data); vals=list(data.values())+[self.selected_leave_id]
            self.q(f'UPDATE "الإجازات" SET {sets} WHERE "رقم_الإجازة"=?',vals); self.commit(); self.load_table("الإجازات"); messagebox.showinfo("تم","تم تعديل الإجازة.")
        except Exception as e: messagebox.showerror("خطأ",str(e))

    def delete_leave(self):
        if not self.selected_leave_id: return
        if not messagebox.askyesno("تأكيد","هل تريد حذف سجل الإجازة؟"): return
        try: self.q('DELETE FROM "الإجازات" WHERE "رقم_الإجازة"=?',(self.selected_leave_id,)); self.commit(); self.clear_leave(); self.load_table("الإجازات")
        except Exception as e: messagebox.showerror("خطأ",str(e))

    def on_leave_select(self,event=None):
        sel=self.tree_الإجازات.selection()
        if not sel: return
        sid=int(self.tree_الإجازات.item(sel[0],"values")[0]); self.selected_leave_id=sid
        cols=[r[1] for r in self.q('PRAGMA table_info("الإجازات")')]; row=self.q('SELECT * FROM "الإجازات" WHERE "رقم_الإجازة"=?',(sid,)).fetchone()
        if not row: return
        d=dict(zip(cols,row)); v=self.v_الإجازات
        for k in v:
            if k=="رقم_المنتسب":
                val=d.get(k); name=self.q("SELECT الاسم_الكامل FROM المنتسبون WHERE رقم_المنتسب=?",(val,)).fetchone(); v[k].set(f"{name[0]} - {val}" if name else str(val or ""))
            else: v[k].set("" if d.get(k) is None else str(d.get(k)))
        self.toggle_leave_mode()
        if v["نوع_الإجازة"].get().strip()=="إجازة زمنية":
            v["تاريخ_الإجازة"].set(d.get("تاريخ_الإجازة") or d.get("من_تاريخ") or "")
            v["من_الساعة"].set(d.get("من_الساعة") or ""); v["إلى_الساعة"].set(d.get("إلى_الساعة") or ""); self.calc_leave_hours()

    def load_leaves_table(self):
        tree=self.tree_الإجازات
        for x in tree.get_children(): tree.delete(x)
        display_cols=["نوع_الإجازة","من_تاريخ","إلى_تاريخ","عدد_الأيام","تاريخ_الإجازة","من_الساعة","إلى_الساعة","عدد_الساعات","حالة_الإجازة"]
        sql = '''SELECT t."رقم_الإجازة", COALESCE(m."الاسم_الكامل",''), t."نوع_الإجازة", t."من_تاريخ", t."إلى_تاريخ", t."عدد_الأيام", COALESCE(t."تاريخ_الإجازة",''), COALESCE(t."من_الساعة",''), COALESCE(t."إلى_الساعة",''), COALESCE(t."عدد_الساعات",''), t."حالة_الإجازة" FROM "الإجازات" t LEFT JOIN "المنتسبون" m ON m."رقم_المنتسب"=t."رقم_المنتسب"'''
        params=[]; search=self.search_الإجازات.get().strip()
        if search:
            conditions=['m."الاسم_الكامل" LIKE ?']; params.append(f"%{search}%")
            for c in display_cols: conditions.append(f'CAST(t."{c}" AS TEXT) LIKE ?'); params.append(f"%{search}%")
            sql += " WHERE " + " OR ".join(conditions)
        sql += ' ORDER BY t."رقم_الإجازة" DESC'
        for r in self.q(sql,params): tree.insert("","end",values=r)
        self.setup_employee_combo_search(self.cb_الإجازات)

    def build_absences_tab(self):
        self.generic_record_tab("الغيابات", "الغيابات",
            ["رقم_المنتسب","تاريخ_الغياب","نوع_الغياب","السبب","الإجراء","ملاحظات"],
            ["تاريخ_الغياب","نوع_الغياب","السبب","الإجراء"],
            ["التاريخ","النوع","السبب","الإجراء"], "رقم_الغياب")

    def build_penalties_tab(self):
        self.generic_record_tab("العقوبات", "العقوبات",
            ["رقم_المنتسب","تاريخ_العقوبة","نوع_العقوبة","سبب_العقوبة","الجهة_المصدرة","رقم_الأمر","تاريخ_الأمر","ملاحظات"],
            ["تاريخ_العقوبة","نوع_العقوبة","سبب_العقوبة","الجهة_المصدرة","رقم_الأمر"],
            ["التاريخ","النوع","السبب","الجهة","رقم الأمر"], "رقم_العقوبة")

    def build_attendance_tab(self):
        self.generic_record_tab("الحضور", "الحضور",
            ["رقم_المنتسب","التاريخ","وقت_الحضور","وقت_الانصراف","حالة_الحضور","ملاحظات"],
            ["التاريخ","وقت_الحضور","وقت_الانصراف","حالة_الحضور"],
            ["التاريخ","الحضور","الانصراف","الحالة"], "رقم_السجل")

    def clear_record(self, table):
        vars = getattr(self, f"v_{table}")
        for v in vars.values():
            v.set("")
        cb = getattr(self, f"cb_{table}", None)
        if cb:
            self.setup_employee_combo_search(cb)
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        setattr(self, f"selected_{key}_id", None)

    def save_record(self, table):
        vars = getattr(self, f"v_{table}")
        data = {k: v.get().strip() for k, v in vars.items()}
        for k, value in data.items():
            if ("تاريخ" in k or k == "التاريخ") and value and not self._valid_date_value(value, allow_year_only=False):
                messagebox.showwarning("تاريخ غير صحيح", f"{k} غير صحيح. اختر التاريخ من زر التقويم 📅.")
                return
        if not data.get("رقم_المنتسب"):
            messagebox.showwarning("تنبيه", "اختر المنتسب.")
            return
        data["رقم_المنتسب"] = self.emp_id_from_text(data["رقم_المنتسب"])
        cols = list(data.keys())
        vals = [data[c] if data[c] != "" else None for c in cols]
        try:
            qs = ",".join(["?"] * len(cols))
            self.q(f'INSERT INTO "{table}" ({",".join(cols)}) VALUES ({qs})', vals)
            self.commit()
            self.load_table(table)
            messagebox.showinfo("تم", "تم حفظ السجل.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def update_record(self, table):
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        sid = getattr(self, f"selected_{key}_id")
        if not sid:
            messagebox.showwarning("تنبيه", "حدد سجلاً أولاً.")
            return
        vars = getattr(self, f"v_{table}")
        data = {k: v.get().strip() for k, v in vars.items()}
        data["رقم_المنتسب"] = self.emp_id_from_text(data["رقم_المنتسب"])
        try:
            sets = ",".join([f'"{c}"=?' for c in data])
            vals = [data[c] if data[c] != "" else None for c in data]
            vals.append(sid)
            self.q(f'UPDATE "{table}" SET {sets} WHERE "{self.idcol(table)}"=?', vals)
            self.commit()
            self.load_table(table)
            messagebox.showinfo("تم", "تم تعديل السجل.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def delete_record(self, table):
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        sid = getattr(self, f"selected_{key}_id")
        if not sid:
            return
        if not messagebox.askyesno("تأكيد", "هل تريد حذف السجل؟"):
            return
        try:
            self.q(f'DELETE FROM "{table}" WHERE "{self.idcol(table)}"=?', (sid,))
            self.commit()
            self.load_table(table)
            self.clear_record(table)
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def idcol(self, table):
        return {"الإجازات":"رقم_الإجازة","الغيابات":"رقم_الغياب","العقوبات":"رقم_العقوبة","الحضور":"رقم_السجل"}[table]

    def emp_id_from_text(self, text):
        # يدعم الصيغة الجديدة "الاسم - الرقم" والقديمة "الرقم - الاسم"
        text = (text or "").strip()
        if " - " in text:
            parts = text.rsplit(" - ", 1)
            try:
                return int(parts[1].strip())
            except Exception:
                try:
                    return int(parts[0].strip())
                except Exception:
                    return None
        try:
            return int(text)
        except Exception:
            row = self.q("SELECT رقم_المنتسب FROM المنتسبون WHERE الاسم_الكامل=?", (text,)).fetchone()
            if row:
                return row[0]
            rows = self.q("SELECT رقم_المنتسب FROM المنتسبون WHERE الاسم_الكامل LIKE ?", (f"%{text}%",)).fetchall()
            return rows[0][0] if len(rows) == 1 else None

    def on_record_select(self, table):
        tree = getattr(self, f"tree_{table}")
        sel = tree.selection()
        if not sel:
            return
        sid = int(tree.item(sel[0], "values")[0])
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        setattr(self, f"selected_{key}_id", sid)

        cols = [r[1] for r in self.q(f'PRAGMA table_info("{table}")')]
        row = self.q(f'SELECT * FROM "{table}" WHERE "{self.idcol(table)}"=?', (sid,)).fetchone()
        d = dict(zip(cols, row))
        vars = getattr(self, f"v_{table}")
        for k, v in vars.items():
            val = d.get(k)
            if k == "رقم_المنتسب" and val is not None:
                name = self.q("SELECT الاسم_الكامل FROM المنتسبون WHERE رقم_المنتسب=?", (val,)).fetchone()
                v.set(f"{name[0]} - {val}" if name else str(val))
            else:
                v.set("" if val is None else str(val))

    def clear_table_search(self, table):
        var = getattr(self, f"search_{table}", None)
        if var is not None:
            var.set("")
            self.load_table(table)

    def load_table(self, table):
        if table == "الإجازات":
            return self.load_leaves_table()
        tree = getattr(self, f"tree_{table}")
        for x in tree.get_children():
            tree.delete(x)

        idc = self.idcol(table)
        maps = {
            "الإجازات":["نوع_الإجازة","من_تاريخ","إلى_تاريخ","عدد_الأيام","حالة_الإجازة"],
            "الغيابات":["تاريخ_الغياب","نوع_الغياب","السبب","الإجراء"],
            "العقوبات":["تاريخ_العقوبة","نوع_العقوبة","سبب_العقوبة","الجهة_المصدرة","رقم_الأمر"],
            "الحضور":["التاريخ","وقت_الحضور","وقت_الانصراف","حالة_الحضور"]
        }

        display_cols = maps[table]
        select_cols = ",".join([f't."{c}"' for c in display_cols])
        sql = f'''SELECT t."{idc}", COALESCE(m."الاسم_الكامل",'') AS "اسم_المنتسب", {select_cols}
                  FROM "{table}" t
                  LEFT JOIN "المنتسبون" m ON m."رقم_المنتسب" = t."رقم_المنتسب"'''
        params = []

        search = getattr(self, f"search_{table}", tk.StringVar()).get().strip()
        if search:
            conditions = ['m."الاسم_الكامل" LIKE ?']
            params.append(f"%{search}%")
            for c in display_cols:
                conditions.append(f'CAST(t."{c}" AS TEXT) LIKE ?')
                params.append(f"%{search}%")
            sql += " WHERE " + " OR ".join(conditions)

        sql += f' ORDER BY t."{idc}" DESC'

        for r in self.q(sql, params):
            tree.insert("", "end", values=r)

        cb = getattr(self, f"cb_{table}", None)
        if cb:
            self.setup_employee_combo_search(cb)

    def build_sections_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="الشعب")

        top = ttk.Frame(tab, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="رقم الشعبة:").pack(side="right", padx=4)
        self.section_id_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.section_id_var, width=12, justify="right").pack(side="right", padx=4)

        ttk.Label(top, text="اسم الشعبة:").pack(side="right", padx=4)
        self.section_name_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.section_name_var, width=35, justify="right").pack(side="right", padx=4)

        ttk.Button(top, text="إضافة شعبة", command=self.add_section).pack(side="right", padx=4)
        ttk.Button(top, text="تعديل الشعبة", command=self.update_section).pack(side="right", padx=4)
        ttk.Button(top, text="حذف الشعبة", command=self.delete_section).pack(side="right", padx=4)
        ttk.Button(top, text="تحديث", command=self.load_sections).pack(side="right", padx=4)

        ttk.Label(tab, text="هذه القائمة هي مصدر أسماء الشعب الظاهرة في معلومات الموظفين.",
                  font=("Tahoma", 10, "bold")).pack(fill="x", padx=12, pady=(0,6))

        frame = ttk.Frame(tab)
        frame.pack(fill="both", expand=True, padx=10, pady=5)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        self.section_tree = ttk.Treeview(frame, columns=("id","name"), show="headings")
        self.section_tree.heading("id", text="رقم الشعبة", anchor="center")
        self.section_tree.heading("name", text="اسم الشعبة", anchor="center")
        self.section_tree.column("id", width=140, anchor="center")
        self.section_tree.column("name", width=500, anchor="center")
        sy = ttk.Scrollbar(frame, orient="vertical", command=self.section_tree.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=self.section_tree.xview)
        self.section_tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        self.section_tree.grid(row=0,column=0,sticky="nsew")
        sy.grid(row=0,column=1,sticky="ns")
        sx.grid(row=1,column=0,sticky="ew")
        self.section_tree.bind("<<TreeviewSelect>>", self.on_section_select)
        self.load_sections()

    def load_sections(self):
        if not hasattr(self, "section_tree"):
            return
        for x in self.section_tree.get_children():
            self.section_tree.delete(x)
        for r in self.q("SELECT رقم_الشعبة,اسم_الشعبة FROM الشعب ORDER BY رقم_الشعبة"):
            self.section_tree.insert("", "end", values=r)
        self.refresh_sections()

    def on_section_select(self, event=None):
        sel = self.section_tree.selection()
        if not sel:
            return
        r = self.section_tree.item(sel[0], "values")
        self.section_id_var.set(r[0])
        self.section_name_var.set(r[1])

    def add_section(self):
        name = self.section_name_var.get().strip()
        if not name:
            messagebox.showwarning("تنبيه", "أدخل اسم الشعبة.")
            return
        raw_id = self.section_id_var.get().strip()
        try:
            if raw_id:
                sid = int(raw_id)
                self.q("INSERT INTO الشعب (رقم_الشعبة,اسم_الشعبة) VALUES (?,?)", (sid, name))
            else:
                row = self.q("SELECT COALESCE(MAX(رقم_الشعبة),0)+1 FROM الشعب").fetchone()
                sid = int(row[0])
                self.q("INSERT INTO الشعب (رقم_الشعبة,اسم_الشعبة) VALUES (?,?)", (sid, name))
            self.commit()
            self.load_sections()
            self.section_id_var.set("")
            self.section_name_var.set("")
            messagebox.showinfo("تم", "تمت إضافة الشعبة، وستظهر مباشرة في معلومات الموظفين.")
        except sqlite3.IntegrityError:
            messagebox.showerror("خطأ", "رقم الشعبة أو اسم الشعبة مستخدم مسبقاً.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def update_section(self):
        sel = self.section_tree.selection()
        if not sel:
            messagebox.showwarning("تنبيه", "حدد الشعبة أولاً.")
            return
        try:
            sid = int(self.section_tree.item(sel[0], "values")[0])
        except Exception:
            messagebox.showerror("خطأ", "رقم الشعبة غير صحيح.")
            return
        name = self.section_name_var.get().strip()
        if not name:
            messagebox.showwarning("تنبيه", "أدخل اسم الشعبة.")
            return
        try:
            self.q("UPDATE الشعب SET اسم_الشعبة=? WHERE رقم_الشعبة=?", (name, sid))
            self.commit()
            self.load_sections()
            self.load_employees()
            messagebox.showinfo("تم", "تم تعديل اسم الشعبة، وتحدثت معلومات الموظفين المرتبطين بها تلقائياً.")
        except sqlite3.IntegrityError:
            messagebox.showerror("خطأ", "اسم الشعبة مستخدم مسبقاً.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def delete_section(self):
        sel = self.section_tree.selection()
        if not sel:
            messagebox.showwarning("تنبيه", "حدد الشعبة أولاً.")
            return
        sid = int(self.section_tree.item(sel[0], "values")[0])
        used = self.q("SELECT COUNT(*) FROM المنتسبون WHERE رقم_الشعبة=?", (sid,)).fetchone()[0]
        if used:
            messagebox.showwarning("لا يمكن الحذف",
                                   f"هذه الشعبة مرتبطة بـ {used} موظف. غيّر شعبة الموظفين أولاً.")
            return
        if not messagebox.askyesno("تأكيد", "هل تريد حذف الشعبة المحددة؟"):
            return
        try:
            self.q("DELETE FROM الشعب WHERE رقم_الشعبة=?", (sid,))
            self.commit()
            self.load_sections()
            self.section_id_var.set("")
            self.section_name_var.set("")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def build_reports_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="التقارير")

        # مجموعة اختيار نوع التقرير بشكل مرتب ومضغوط.
        top = ttk.Frame(tab, padding=(10,6,10,4))
        top.pack(fill="x")
        report_box = ttk.LabelFrame(top, text="نوع التقرير", padding=(7,5))
        report_box.pack(side="right", fill="x", expand=True, padx=(0,6))
        ttk.Button(report_box, text="المنتسبون", command=self.report_employees).pack(side="right", padx=2)
        ttk.Button(report_box, text="الإجازات", command=self.report_leaves).pack(side="right", padx=2)
        ttk.Button(report_box, text="الغيابات", command=self.report_absences).pack(side="right", padx=2)
        ttk.Button(report_box, text="العقوبات", command=self.report_penalties).pack(side="right", padx=2)
        ttk.Button(report_box, text="الحضور", command=self.report_attendance).pack(side="right", padx=2)

        action_box = ttk.LabelFrame(top, text="إجراءات", padding=(7,5))
        action_box.pack(side="left", padx=(6,0))
        ttk.Button(action_box, text="Excel / CSV", command=self.save_report_csv).pack(side="left", padx=2)
        ttk.Button(action_box, text="طباعة", command=self.print_report).pack(side="left", padx=2)
        ttk.Button(action_box, text="إحصائيات", command=self.show_stats).pack(side="left", padx=2)

        filt = ttk.LabelFrame(tab, text="تصفية التقرير", padding=(10,7))
        filt.pack(fill="x", padx=10, pady=(0,6))
        self.report_emp_var = tk.StringVar()
        self.report_from_var = tk.StringVar()
        self.report_to_var = tk.StringVar()
        lbl="FieldLabel.TLabel"
        ttk.Label(filt,text="الاسم",style=lbl).grid(row=0,column=0,padx=(0,4),pady=2)
        self.report_emp_combo=ttk.Combobox(filt,textvariable=self.report_emp_var,state="normal",width=24,justify="right")
        self.report_emp_combo.grid(row=0,column=1,padx=(0,10),pady=2)
        self.setup_employee_combo_search(self.report_emp_combo)
        ttk.Label(filt,text="من تاريخ",style=lbl).grid(row=0,column=2,padx=(0,4),pady=2)
        ttk.Entry(filt,textvariable=self.report_from_var,state="readonly",width=12,justify="center").grid(row=0,column=3,padx=(0,3),pady=2)
        ttk.Button(filt,text="📅",width=3,command=lambda: DatePicker(self.root,self.report_from_var,"من تاريخ التقرير")).grid(row=0,column=4,padx=(0,10),pady=2)
        ttk.Label(filt,text="إلى تاريخ",style=lbl).grid(row=0,column=5,padx=(0,4),pady=2)
        ttk.Entry(filt,textvariable=self.report_to_var,state="readonly",width=12,justify="center").grid(row=0,column=6,padx=(0,3),pady=2)
        ttk.Button(filt,text="📅",width=3,command=lambda: DatePicker(self.root,self.report_to_var,"إلى تاريخ التقرير")).grid(row=0,column=7,padx=(0,10),pady=2)
        ttk.Button(filt,text="تطبيق",command=self.refresh_current_report).grid(row=0,column=8,padx=2,pady=2)
        ttk.Button(filt,text="ملخص الاسم",command=self.report_employee_summary).grid(row=0,column=9,padx=2,pady=2)
        ttk.Button(filt,text="مسح",command=self.clear_report_filters).grid(row=0,column=10,padx=2,pady=2)

        self.report_title = tk.StringVar(value="اختر نوع التقرير")
        ttk.Label(tab, textvariable=self.report_title,
                  font=("Tahoma", 12, "bold")).pack(fill="x", padx=10, pady=(1, 4))

        frame = ttk.Frame(tab)
        frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.report_tree = ttk.Treeview(frame, show="headings")
        self.report_tree.grid(row=0, column=0, sticky="nsew")
        sy = ttk.Scrollbar(frame, orient="vertical", command=self.report_tree.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=self.report_tree.xview)
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        self.report_tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        style = ttk.Style()
        style.configure("Report.Treeview", rowheight=27, font=("Tahoma", 9))
        style.configure("Report.Treeview.Heading", font=("Tahoma", 9, "bold"))
        self.report_tree.configure(style="Report.Treeview")

        self.current_report_title = ""
        self.current_report_headers = []
        self.current_report_rows = []

    def set_report(self, title, rows, headers):
        self.current_report_title = title
        self.current_report_headers = headers
        self.current_report_rows = rows
        self.report_title.set(title)

        for item in self.report_tree.get_children():
            self.report_tree.delete(item)

        cols = [f"c{i}" for i in range(len(headers))]
        self.report_tree["columns"] = cols

        for i, (col, heading) in enumerate(zip(cols, headers)):
            self.report_tree.heading(col, text=heading, anchor="center")
            width = 125
            if any(x in heading for x in ("الاسم", "المنتسب", "السبب")):
                width = 190
            elif any(x in heading for x in ("التاريخ", "من", "إلى")):
                width = 105
            elif any(x in heading for x in ("الأيام", "رقم")):
                width = 75
            self.report_tree.column(col, width=width, minwidth=80, anchor="center")

        for idx, row in enumerate(rows):
            vals = ["" if x is None else str(x) for x in row]
            self.report_tree.insert("", "end", values=vals, tags=("even" if idx % 2 == 0 else "odd",))

        self.report_tree.tag_configure("even", background="#f7f7f7")
        self.report_tree.tag_configure("odd", background="#ffffff")

    def clear_report_filters(self):
        self.report_emp_var.set("")
        self.report_from_var.set("")
        self.report_to_var.set("")
        self.report_title.set("اختر نوع التقرير")
        for item in self.report_tree.get_children(): self.report_tree.delete(item)

    def _report_employee_id(self):
        text=(self.report_emp_var.get() or "").strip()
        if not text: return None
        return self.emp_id_from_text(text)

    def _report_filter_values(self, date_col, alias, params, conditions):
        eid=self._report_employee_id()
        text=self.report_emp_var.get().strip()
        if text:
            if eid:
                conditions.append(f'{alias}."رقم_المنتسب" = ?'); params.append(eid)
            else:
                conditions.append(f'{alias}."الاسم_الكامل" LIKE ?'); params.append(f'%{text}%')
        f=self.parse_leave_date(self.report_from_var.get()); t=self.parse_leave_date(self.report_to_var.get())
        if f: conditions.append(f'normdate({date_col}) >= ?'); params.append(f.strftime("%Y-%m-%d"))
        if t: conditions.append(f'normdate({date_col}) <= ?'); params.append(t.strftime("%Y-%m-%d"))

    def refresh_current_report(self):
        if self.report_emp_var.get().strip():
            f=self.parse_leave_date(self.report_from_var.get()); t=self.parse_leave_date(self.report_to_var.get())
            if not f or not t or t<f:
                messagebox.showwarning("تنبيه","عند البحث باسم منتسب يجب تحديد من تاريخ وإلى تاريخ.")
                return
        title=self.current_report_title or ""
        if "الإجازات" in title: self.report_leaves()
        elif "الغيابات" in title: self.report_absences()
        elif "العقوبات" in title: self.report_penalties()
        elif "الحضور" in title: self.report_attendance()
        elif "المنتسبين" in title: self.report_employees()
        else: messagebox.showinfo("تنبيه","اختر نوع التقرير أولاً.")

    def report_employee_summary(self):
        text=self.report_emp_var.get().strip()
        if not text:
            messagebox.showwarning("تنبيه","اكتب أو اختر اسم المنتسب أولاً."); return
        f=self.parse_leave_date(self.report_from_var.get()); t=self.parse_leave_date(self.report_to_var.get())
        if not f or not t or t<f:
            messagebox.showwarning("تنبيه","حدد تاريخ البداية والنهاية بشكل صحيح."); return
        eid=self._report_employee_id()
        fs=f.strftime("%Y-%m-%d"); ts=t.strftime("%Y-%m-%d")
        def count(table,datecol):
            if eid:
                q=f'SELECT COUNT(*) FROM "{table}" WHERE "رقم_المنتسب"=? AND normdate("{datecol}") BETWEEN ? AND ?'
                return self.q(q,(eid,fs,ts)).fetchone()[0]
            q=f'SELECT COUNT(*) FROM "{table}" x JOIN "المنتسبون" m ON m."رقم_المنتسب"=x."رقم_المنتسب" WHERE m."الاسم_الكامل" LIKE ? AND normdate(x."{datecol}") BETWEEN ? AND ?'
            return self.q(q,(f'%{text}%',fs,ts)).fetchone()[0]
        leaves=count("الإجازات","من_تاريخ"); absences=count("الغيابات","تاريخ_الغياب"); penalties=count("العقوبات","تاريخ_العقوبة"); attendance=count("الحضور","التاريخ")
        name=text
        if eid:
            r=self.q('SELECT الاسم_الكامل FROM المنتسبون WHERE رقم_المنتسب=?',(eid,)).fetchone()
            if r: name=r[0]
        self.set_report("ملخص المنتسب",[(name,fs,ts,leaves,absences,penalties,attendance)], ["المنتسب","من تاريخ","إلى تاريخ","عدد الإجازات","عدد الغيابات","عدد العقوبات","سجلات الحضور"])

    def report_employees(self):
        rows = self.q("""SELECT م.الرقم_الوظيفي,م.الاسم_الكامل,
                         ش.اسم_الشعبة,COALESCE(م.الفرع_الوحدة,''),
                         م.المسمى_الوظيفي,م.الحالة
                         FROM المنتسبون م LEFT JOIN الشعب ش ON ش.رقم_الشعبة=م.رقم_الشعبة
                         ORDER BY م.رقم_المنتسب""").fetchall()
        self.set_report("تقرير المنتسبين - قسم التربية والتعليم", rows,
                        ["الرقم الوظيفي","الاسم الكامل","الشعبة","الفرع / الوحدة","المسمى الوظيفي","الحالة"])

    def report_leaves(self):
        params=[]; conditions=[]; self._report_filter_values('إ.من_تاريخ','م',params,conditions)
        where=(' WHERE '+' AND '.join(conditions)) if conditions else ''
        rows=self.q(f'''SELECT م.الاسم_الكامل,إ.نوع_الإجازة,
                               CASE WHEN إ.نوع_الإجازة='إجازة زمنية' THEN COALESCE(إ.تاريخ_الإجازة,إ.من_تاريخ) ELSE إ.من_تاريخ END,
                               CASE WHEN إ.نوع_الإجازة='إجازة زمنية' THEN COALESCE(إ.من_الساعة,'') ELSE إ.إلى_تاريخ END,
                               CASE WHEN إ.نوع_الإجازة='إجازة زمنية' THEN COALESCE(إ.إلى_الساعة,'') ELSE CAST(إ.عدد_الأيام AS TEXT) END,
                               CASE WHEN إ.نوع_الإجازة='إجازة زمنية' THEN COALESCE(إ.عدد_الساعات,'') ELSE '' END,
                               COALESCE(إ.سبب_الإجازة,''),إ.حالة_الإجازة
                        FROM الإجازات إ JOIN المنتسبون م ON م.رقم_المنتسب=إ.رقم_المنتسب{where}
                        ORDER BY إ.رقم_الإجازة DESC''',params).fetchall()
        self.set_report("تقرير الإجازات",rows,["المنتسب","نوع الإجازة","التاريخ/من","الوقت/إلى","الأيام/إلى الساعة","الساعات","السبب","الحالة"])

    def report_absences(self):
        params=[]; conditions=[]; self._report_filter_values('غ.تاريخ_الغياب','م',params,conditions)
        where=(' WHERE '+' AND '.join(conditions)) if conditions else ''
        rows=self.q(f'''SELECT م.الاسم_الكامل,غ.تاريخ_الغياب,غ.نوع_الغياب,غ.السبب,غ.الإجراء
                         FROM الغيابات غ JOIN المنتسبون م ON م.رقم_المنتسب=غ.رقم_المنتسب{where}
                         ORDER BY غ.رقم_الغياب DESC''',params).fetchall()
        self.set_report("تقرير الغيابات",rows,["المنتسب","التاريخ","النوع","السبب","الإجراء"])

    def report_penalties(self):
        params=[]; conditions=[]; self._report_filter_values('ع.تاريخ_العقوبة','م',params,conditions)
        where=(' WHERE '+' AND '.join(conditions)) if conditions else ''
        rows=self.q(f'''SELECT م.الاسم_الكامل,ع.تاريخ_العقوبة,ع.نوع_العقوبة,ع.سبب_العقوبة,ع.الجهة_المصدرة,ع.رقم_الأمر
                         FROM العقوبات ع JOIN المنتسبون م ON م.رقم_المنتسب=ع.رقم_المنتسب{where}
                         ORDER BY ع.رقم_العقوبة DESC''',params).fetchall()
        self.set_report("تقرير العقوبات",rows,["المنتسب","التاريخ","النوع","السبب","الجهة","رقم الأمر"])

    def report_attendance(self):
        params=[]; conditions=[]; self._report_filter_values('ح.التاريخ','م',params,conditions)
        where=(' WHERE '+' AND '.join(conditions)) if conditions else ''
        rows=self.q(f'''SELECT م.الاسم_الكامل,ح.التاريخ,ح.وقت_الحضور,ح.وقت_الانصراف,ح.حالة_الحضور
                         FROM الحضور ح JOIN المنتسبون م ON م.رقم_المنتسب=ح.رقم_المنتسب{where}
                         ORDER BY ح.رقم_السجل DESC''',params).fetchall()
        self.set_report("تقرير الحضور",rows,["المنتسب","التاريخ","الحضور","الانصراف","الحالة"])

    def save_report_csv(self):
        if not self.current_report_rows:
            messagebox.showwarning("تنبيه", "أنشئ تقريراً أولاً.")
            return
        import csv
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV - يفتح في Excel","*.csv")],
            title="حفظ التقرير كجدول"
        )
        if path:
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f)
                w.writerow(self.current_report_headers)
                w.writerows(self.current_report_rows)
            messagebox.showinfo("تم", "تم حفظ التقرير كجدول يمكن فتحه في Excel.")

    def print_report(self):
        if not self.current_report_rows:
            messagebox.showwarning("تنبيه", "أنشئ تقريراً أولاً.")
            return

        import html, os
        headers_html = "".join(f"<th>{html.escape(str(h))}</th>" for h in self.current_report_headers)
        rows_html = []
        for row in self.current_report_rows:
            cells = "".join(f"<td>{html.escape('' if x is None else str(x))}</td>" for x in row)
            rows_html.append(f"<tr>{cells}</tr>")

        page = f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>{html.escape(self.current_report_title)}</title>
<style>
body {{ font-family: Tahoma, Arial, sans-serif; direction: rtl; margin: 25px; }}
h2 {{ text-align: center; margin-bottom: 20px; }}
table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
th, td {{ border: 1px solid #555; padding: 7px; text-align: center; }}
th {{ font-weight: bold; background: #eaeaea; }}
tr:nth-child(even) {{ background: #f7f7f7; }}
@media print {{ @page {{ size: A4 landscape; margin: 10mm; }} }}
</style>
<script>
window.addEventListener('load', function() {{
    setTimeout(function() {{ window.print(); }}, 500);
}});
</script>
</head>
<body>
<h2>{html.escape(self.current_report_title)}</h2>
<table><thead><tr>{headers_html}</tr></thead>
<tbody>{''.join(rows_html)}</tbody></table>
</body></html>"""

        path = BASE_DIR / "تقرير_للطباعة.html"
        try:
            path.write_text(page, encoding="utf-8")
            # لا نعتمد على ربط امتداد HTML في ويندوز، لأنه قد يكون غير مضبوط.
            # بدلاً من ذلك نفتحه في المتصفح الافتراضي مباشرة ثم تظهر نافذة الطباعة.
            import webbrowser
            opened = webbrowser.open(path.as_uri(), new=2)
            if not opened:
                raise RuntimeError("تعذر فتح التقرير في المتصفح الافتراضي.")
        except Exception as e:
            messagebox.showerror("خطأ في الطباعة",
                                 f"تعذر فتح تقرير الطباعة في المتصفح.\n"
                                 f"يمكنك فتح الملف يدوياً ثم اختيار طباعة:\n{path}\n\n{e}")

    def show_stats(self):
        try:
            emp = self.q("SELECT COUNT(*) FROM المنتسبون").fetchone()[0]
            leaves = self.q("SELECT COUNT(*) FROM الإجازات").fetchone()[0]
            absences = self.q("SELECT COUNT(*) FROM الغيابات").fetchone()[0]
            penalties = self.q("SELECT COUNT(*) FROM العقوبات").fetchone()[0]
            attendance = self.q("SELECT COUNT(*) FROM الحضور").fetchone()[0]
            msg = (
                f"عدد المنتسبين: {emp}\n"
                f"عدد الإجازات: {leaves}\n"
                f"عدد الغيابات: {absences}\n"
                f"عدد العقوبات: {penalties}\n"
                f"سجلات الحضور: {attendance}"
            )
            messagebox.showinfo("إحصائيات النظام", msg)
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def load_all(self):
        if not self.conn:
            return
        self.refresh_sections()
        self.load_employees()
        if hasattr(self, "section_tree"):
            self.load_sections()
        for t in ("الإجازات","الغيابات","العقوبات","الحضور"):
            self.load_table(t)

    def backup_db(self):
        try:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            target = BASE_DIR / f"نسخة_احتياطية_{stamp}.sqlite"
            shutil.copy2(DB_PATH, target)
            messagebox.showinfo("نسخة احتياطية", f"تم حفظ نسخة احتياطية:\n{target.name}")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def close(self):
        try:
            if self.conn:
                self.conn.close()
        finally:
            self.root.destroy()

def ensure_google_libs_global():
    global GOOGLE_LIBS_AVAILABLE, InstalledAppFlow, Request
    if GOOGLE_LIBS_AVAILABLE:
        return True
    try:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '--user', 'google-auth-oauthlib', 'requests'])
        from google_auth_oauthlib.flow import InstalledAppFlow as _Flow
        from google.auth.transport.requests import Request as _Request
        InstalledAppFlow = _Flow
        Request = _Request
        GOOGLE_LIBS_AVAILABLE = True
        return True
    except Exception as e:
        messagebox.showerror('Google', 'تعذر تثبيت مكونات Google تلقائياً.\n\n' + str(e))
        return False

def google_login(db_path):
    if not ensure_google_libs_global():
        return False
    credentials_path = BASE_DIR / 'credentials.json'
    if not credentials_path.exists():
        messagebox.showinfo('إعداد Google', 'لا يوجد ملف credentials.json بعد. يجب إنشاء OAuth Client من Google Cloud ووضع الملف بجانب البرنامج مرة واحدة.')
        return False
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute("SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='Google_Email'").fetchone()
        linked_email = (row[0] if row else '').strip().lower()
        subrow = conn.execute("SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='Google_Sub'").fetchone()
        linked_sub = subrow[0] if subrow else ''
        if not linked_email or not linked_sub:
            messagebox.showwarning('Google', 'لا يوجد حساب Google مربوط بهذا النظام. اربطه أولاً من الإعدادات.')
            return False
        flow=InstalledAppFlow.from_client_secrets_file(str(credentials_path), scopes=['openid','email','profile'])
        creds=flow.run_local_server(port=0, open_browser=True)
        import requests
        r=requests.get('https://openidconnect.googleapis.com/v1/userinfo', headers={'Authorization': f'Bearer {creds.token}'}, timeout=20)
        r.raise_for_status()
        data=r.json()
        if data.get('email','').lower() != linked_email or data.get('sub','') != linked_sub:
            messagebox.showerror('رفض الدخول', 'حساب Google الذي سجلت به ليس الحساب المرتبط بهذا النظام.')
            return False
        return True
    except Exception as e:
        messagebox.showerror('Google', f'تعذر تسجيل الدخول بحساب Google:\n{e}')
        return False
    finally:
        conn.close()

def google_recovery(db_path):
    if not ensure_google_libs_global():
        return False
    credentials_path = BASE_DIR / 'credentials.json'
    if not credentials_path.exists():
        messagebox.showinfo('Google', 'ملف ربط Google غير موجود بعد. بعد إنشاء OAuth Client من Google Cloud، ضع ملف credentials.json بجانب البرنامج مرة واحدة.')
        return False
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute("SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='Google_Email'").fetchone()
        linked_email = (row[0] if row else '').strip().lower()
        linked_sub_row = conn.execute("SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='Google_Sub'").fetchone()
        linked_sub = linked_sub_row[0] if linked_sub_row else ''
        if not linked_email or not linked_sub:
            messagebox.showwarning('استعادة كلمة المرور', 'لا يوجد حساب Google مربوط بهذا النظام. يجب ربطه مسبقاً من الإعدادات.')
            return False
        scopes=['openid','email','profile']
        flow=InstalledAppFlow.from_client_secrets_file(str(credentials_path), scopes=scopes)
        creds=flow.run_local_server(port=0, open_browser=True)
        import requests
        r=requests.get('https://openidconnect.googleapis.com/v1/userinfo', headers={'Authorization': f'Bearer {creds.token}'}, timeout=20)
        r.raise_for_status()
        data=r.json()
        if data.get('email','').lower() != linked_email or data.get('sub','') != linked_sub:
            messagebox.showerror('رفض الاستعادة', 'حساب Google الذي سجلت به ليس الحساب المرتبط بهذا النظام.')
            return False
        new1=simpledialog.askstring('استعادة كلمة المرور', 'أدخل كلمة المرور الجديدة:', show='*')
        if new1 is None: return False
        if len(new1)<4:
            messagebox.showwarning('تنبيه','كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل.')
            return False
        new2=simpledialog.askstring('استعادة كلمة المرور', 'أعد إدخال كلمة المرور الجديدة:', show='*')
        if new1 != new2:
            messagebox.showerror('خطأ','كلمتا المرور غير متطابقتين.')
            return False
        conn.execute("UPDATE إعدادات_النظام SET القيمة=? WHERE المفتاح='كلمة_المرور'", (hashlib.sha256(new1.encode('utf-8')).hexdigest(),))
        conn.commit()
        messagebox.showinfo('تم', 'تمت استعادة كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول.')
        return True
    except Exception as e:
        messagebox.showerror('Google', f'تعذر التحقق من حساب Google:\n{e}')
        return False
    finally:
        conn.close()

def verify_login(db_path):
    conn = None
    try:
        conn = sqlite3.connect(str(db_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS إعدادات_النظام (
                المفتاح TEXT PRIMARY KEY,
                القيمة TEXT NOT NULL
            )
        """)
        row = conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='كلمة_المرور'"
        ).fetchone()
        if not row:
            conn.execute(
                "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)",
                ('كلمة_المرور', hashlib.sha256('1234'.encode('utf-8')).hexdigest())
            )
            conn.commit()
            stored = hashlib.sha256('1234'.encode('utf-8')).hexdigest()
        else:
            stored = row[0]

        root = tk.Tk()
        root.withdraw()
        result = {'ok': False}
        login = tk.Toplevel(root)
        login.title('تسجيل الدخول')
        login.geometry('430x300')
        login.resizable(False, False)
        login.grab_set()
        ttk.Label(login, text=APP_TITLE, font=('Tahoma', 15, 'bold')).pack(pady=(20,8))
        ttk.Label(login, text='أدخل كلمة المرور أو استخدم حساب Google المرتبط').pack(pady=5)
        ent = ttk.Entry(login, show='*', width=32)
        ent.pack(pady=10)
        ent.focus_set()

        def do_password():
            if hashlib.sha256(ent.get().encode('utf-8')).hexdigest() == stored:
                result['ok']=True
                login.destroy()
            else:
                messagebox.showerror('خطأ', 'كلمة المرور غير صحيحة.', parent=login)

        def do_google_login():
            login.destroy()
            if google_login(db_path):
                result['ok'] = True

        def do_forgot():
            login.destroy()
            if google_recovery(db_path):
                result['ok'] = True

        # الدخول متاح بطريقتين: الضغط بالماوس على زر الدخول أو Enter من لوحة المفاتيح.
        login_btn = ttk.Button(login, text='دخول بكلمة المرور', command=do_password)
        login_btn.pack(pady=5, ipadx=18)
        ttk.Button(login, text='تسجيل الدخول بحساب Google', command=do_google_login).pack(pady=5)
        ttk.Button(login, text='نسيت كلمة المرور؟', command=do_forgot).pack(pady=5)
        login.bind('<Return>', lambda e: do_password())
        login.bind('<KP_Enter>', lambda e: do_password())
        login.after(100, ent.focus_force)
        login.protocol('WM_DELETE_WINDOW', login.destroy)
        root.wait_window(login)
        root.destroy()
        return result['ok']
    except Exception as e:
        try:
            if conn:
                conn.close()
        except Exception:
            pass
        messagebox.showerror('خطأ', f'تعذر تجهيز تسجيل الدخول:\n{e}')
        return False
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    if not DB_PATH.exists():
        picker = tk.Tk()
        picker.withdraw()
        messagebox.showinfo(
            "اختيار قاعدة البيانات",
            "لم يتم العثور على ملف قاعدة البيانات تلقائياً.\n\nاختر الآن ملف: بيانات_شعبة_الصيانة.sqlite أو ملف قاعدة البيانات الحالي.",
            parent=picker
        )
        selected = filedialog.askopenfilename(
            parent=picker,
            title="اختيار قاعدة بيانات شعبة الصيانة",
            filetypes=[("قواعد بيانات SQLite", "*.sqlite *.db"), ("كل الملفات", "*.*")]
        )
        picker.destroy()
        if not selected:
            raise SystemExit
        candidate = Path(selected)
        if not _is_valid_db(candidate):
            root = tk.Tk(); root.withdraw()
            messagebox.showerror("قاعدة البيانات", "الملف المختار ليس قاعدة بيانات شعبة الصيانة أو جداولها غير مكتملة.")
            root.destroy()
            raise SystemExit
        DB_PATH = candidate

    if not verify_login(DB_PATH):
        raise SystemExit

    root = tk.Tk()
    app = App(root)
    if app.conn:
        app.apply_theme()
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()
