MaintenanceSystem Update 1.0.29

This update is based on the current 1.0.26 package and keeps the existing database and program settings.
Changes:
- Converts the main navigation capsules to clear icon-based buttons.
- Removes the main "الشعب" navigation button; section management is available from "الإعدادات".
- Changes the employee "التحرير" area to a dedicated edit button and locks employee fields by default to prevent accidental changes.
- Enables editing only after pressing "تحرير" and locks the fields again after completing the operation.
- Improves Arabic RTL reading behavior in employee information fields on Windows.
- No database is included.
