# -*- coding: utf-8 -*-
import sys, urllib.request, tempfile, zipfile, shutil, time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

def main():
    if len(sys.argv) < 4:
        return
    url = sys.argv[1]
    app_dir = Path(sys.argv[2]).resolve()
    version = sys.argv[3]
    root = tk.Tk(); root.withdraw()
    try:
        tmp = Path(tempfile.gettempdir()) / f'MaintenanceSystem_update_{version}.zip'
        urllib.request.urlretrieve(url, tmp)
        with zipfile.ZipFile(tmp, 'r') as z:
            names = z.namelist()
            if not names:
                raise ValueError('حزمة التحديث فارغة')
            # Extract to a temporary folder first, then replace program files only.
            stage = Path(tempfile.gettempdir()) / f'MaintenanceSystem_stage_{version}'
            if stage.exists(): shutil.rmtree(stage, ignore_errors=True)
            stage.mkdir(parents=True)
            z.extractall(stage)
        time.sleep(1.5)
        # If archive has a single top-level folder, use it.
        roots = [p for p in stage.iterdir()]
        source = roots[0] if len(roots)==1 and roots[0].is_dir() else stage
        for p in source.rglob('*'):
            rel = p.relative_to(source)
            if rel.name.lower() in {'maintenance_data.sqlite', 'بيانات_شعبة_الصيانة.sqlite'}:
                continue
            dest = app_dir / rel
            if p.is_dir():
                dest.mkdir(parents=True, exist_ok=True)
            else:
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dest)
        shutil.rmtree(stage, ignore_errors=True)
        try: tmp.unlink()
        except: pass
        messagebox.showinfo('تحديث النظام', f'تم تثبيت الإصدار {version} بنجاح.')
        exe = app_dir / 'MaintenanceSystem.exe'
        if exe.exists():
            import subprocess
            subprocess.Popen([str(exe)], cwd=str(app_dir))
    except Exception as e:
        messagebox.showerror('تحديث النظام', f'فشل التحديث:\n{e}')
    finally:
        root.destroy()

if __name__ == '__main__':
    main()
