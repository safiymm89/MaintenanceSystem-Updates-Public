@echo off
cd /d "%~dp0"
pyinstaller --noconfirm --clean --onedir --windowed --name MaintenanceSystem MaintenanceSystem.py
pyinstaller --noconfirm --clean --onedir --windowed --name Updater Updater.py
copy /Y maintenance_data.sqlite dist\MaintenanceSystem\maintenance_data.sqlite >nul
copy /Y dist\Updater\Updater.exe dist\MaintenanceSystem\Updater.exe >nul
copy /Y BUILD.bat dist\MaintenanceSystem\BUILD.bat >nul
if exist dist\MaintenanceSystem\_internal\MaintenanceSystem.py del /q dist\MaintenanceSystem\_internal\MaintenanceSystem.py
if exist dist\MaintenanceSystem\_internal\Updater.py del /q dist\MaintenanceSystem\_internal\Updater.py
 echo.
echo DONE
echo Open dist\MaintenanceSystem\MaintenanceSystem.exe
echo.
pause
