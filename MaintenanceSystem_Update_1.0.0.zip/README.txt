نظام إدارة الموظفين - نسخة مجهزة للتحديث المركزي

البرنامج يحافظ على maintenance_data.sqlite محلياً ولا يستبدله أثناء التحديث.
أداة Updater.exe مسؤولة عن تنزيل حزمة البرنامج واستبدال ملفات البرنامج فقط.

لربط السيرفر لاحقاً:
عدّل UPDATE_INFO_URL داخل MaintenanceSystem.py إلى رابط latest.json ثم أعد البناء.
صيغة latest.json:
{"version":"1.0.1","package_url":"https://example.com/MaintenanceSystem_1.0.1.zip"}

مهم: قاعدة البيانات المحلية لا تدخل ضمن حزمة التحديث.
