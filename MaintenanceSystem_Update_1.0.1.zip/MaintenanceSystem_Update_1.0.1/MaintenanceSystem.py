# -*- coding: utf-8 -*-
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from pathlib import Path
from datetime import datetime
import shutil
import hashlib
import json
import webbrowser

try:
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    GOOGLE_LIBS_AVAILABLE = True
except Exception:
    GOOGLE_LIBS_AVAILABLE = False

APP_TITLE = "إدارة نظام الموظفين"
APP_VERSION = "1.0.1"
DB_NAME = "بيانات_شعبة_الصيانة.sqlite"
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / DB_NAME

class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1250x760")
        self.root.minsize(1050, 650)
        self.root.option_add("*Font", ("Tahoma", 10))
        self.conn = None
        self.selected_employee_id = None
        self.selected_leave_id = None
        self.selected_absence_id = None
        self.selected_penalty_id = None
        self.selected_attendance_id = None

        if not DB_PATH.exists():
            messagebox.showerror("قاعدة البيانات", f"لم يتم العثور على قاعدة البيانات:\n{DB_PATH}\n\nضع ملف {DB_NAME} بجانب البرنامج.")
            root.destroy()
            return
        try:
            self.conn = sqlite3.connect(str(DB_PATH))
            self.conn.execute("PRAGMA foreign_keys=ON")
            self.validate_db()
            self.ensure_settings()
        except Exception as e:
            messagebox.showerror("خطأ", f"تعذر فتح قاعدة البيانات:\n{e}")
            root.destroy()
            return

        self.build_ui()
        self.load_all()

    def validate_db(self):
        required = {"الأقسام","المنتسبون","الإجازات","الغيابات","العقوبات","الحضور"}
        found = {r[0] for r in self.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        missing = required - found
        if missing:
            raise RuntimeError("الجداول التالية مفقودة: " + ", ".join(sorted(missing)))

    def q(self, sql, params=()):
        return self.conn.execute(sql, params)

    def commit(self):
        self.conn.commit()

    def build_ui(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        header = ttk.Frame(self.root, padding=10)
        header.pack(fill="x")
        ttk.Label(header, text=APP_TITLE, font=("Tahoma", 18, "bold")).pack(side="right")
        ttk.Button(header, text="نسخ احتياطي", command=self.backup_db).pack(side="left", padx=5)
        ttk.Button(header, text="تحديث", command=self.load_all).pack(side="left", padx=5)
        ttk.Label(header, text=f"قاعدة البيانات: {DB_NAME}", font=("Tahoma", 9)).pack(side="left", padx=15)

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(0,10))

        self.build_employees_tab()
        self.build_leaves_tab()
        self.build_absences_tab()
        self.build_penalties_tab()
        self.build_attendance_tab()
        self.build_reports_tab()
        self.build_settings_tab()

    def ensure_settings(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS إعدادات_النظام (
                المفتاح TEXT PRIMARY KEY,
                القيمة TEXT NOT NULL
            )
        """)
        row = self.conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='كلمة_المرور'"
        ).fetchone()
        if not row:
            self.conn.execute(
                "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)",
                ('كلمة_المرور', self.hash_password('1234'))
            )
        row = self.conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='لون_الواجهة'"
        ).fetchone()
        if not row:
            self.conn.execute(
                "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)",
                ('لون_الواجهة', 'أزرق')
            )
        defaults = {
            'بريد_الاستعادة': '',
            'Google_Email': '',
            'Google_Sub': ''
        }
        for k, v in defaults.items():
            if self.conn.execute("SELECT 1 FROM إعدادات_النظام WHERE المفتاح=?", (k,)).fetchone() is None:
                self.conn.execute("INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)", (k, v))
        self.conn.commit()

    @staticmethod
    def hash_password(password):
        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def get_setting(self, key, default=''):
        row = self.conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح=?", (key,)
        ).fetchone()
        return row[0] if row else default

    def set_setting(self, key, value):
        self.conn.execute(
            "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?) "
            "ON CONFLICT(المفتاح) DO UPDATE SET القيمة=excluded.القيمة",
            (key, value)
        )
        self.conn.commit()

    def apply_theme(self, theme_name=None):
        if not self.conn:
            return
        theme_name = theme_name or self.get_setting('لون_الواجهة', 'أزرق')
        palettes = {
            'أزرق': ('#eaf2f8', '#1f4e78', '#ffffff'),
            'أخضر': ('#eaf7ee', '#2e6b3e', '#ffffff'),
            'رمادي': ('#eeeeee', '#555555', '#ffffff'),
            'بني': ('#f5eee6', '#795548', '#ffffff'),
        }
        bg, accent, fg = palettes.get(theme_name, palettes['أزرق'])
        style = ttk.Style(self.root)
        try:
            style.configure('TFrame', background=bg)
            style.configure('TLabelframe', background=bg)
            style.configure('TLabelframe.Label', background=bg, foreground=accent)
            style.configure('TLabel', background=bg)
            style.configure('TButton', padding=5)
            style.configure('TNotebook', background=bg)
            style.configure('TNotebook.Tab', padding=(18, 10), font=('Tahoma', 11, 'bold'))
            style.configure('Treeview', rowheight=27)
            style.configure('Treeview.Heading', font=('Tahoma', 10, 'bold'))
        except Exception:
            pass
        self.root.configure(bg=bg)

    def build_settings_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text='⚙  الإعدادات')

        box = ttk.LabelFrame(tab, text='إعدادات النظام', padding=15)
        box.pack(fill='x', padx=20, pady=20)

        ttk.Label(box, text='تسجيل الدخول والحساب', font=('Tahoma', 12, 'bold')).grid(row=0, column=0, columnspan=3, sticky='e', pady=(0,10))
        ttk.Label(box, text='كلمة المرور:').grid(row=1, column=0, padx=8, pady=8, sticky='e')
        ttk.Button(box, text='تغيير كلمة المرور', command=self.change_password).grid(row=1, column=1, padx=8, pady=8, sticky='w')

        ttk.Label(box, text='البريد الإلكتروني:').grid(row=2, column=0, padx=8, pady=8, sticky='e')
        self.recovery_var = tk.StringVar(value=self.get_setting('بريد_الاستعادة', ''))
        ttk.Entry(box, textvariable=self.recovery_var, width=34).grid(row=2, column=1, padx=8, pady=8, sticky='w')
        ttk.Button(box, text='حفظ البريد', command=self.save_recovery_email).grid(row=2, column=2, padx=8, pady=8)

        ttk.Label(box, text='حساب Google:').grid(row=3, column=0, padx=8, pady=8, sticky='e')
        google_email = self.get_setting('Google_Email', '')
        self.google_status_var = tk.StringVar(value=google_email if google_email else 'غير مربوط')
        ttk.Label(box, textvariable=self.google_status_var).grid(row=3, column=1, padx=8, pady=8, sticky='w')
        ttk.Button(box, text='ربط / تسجيل الدخول بحساب Google', command=self.link_google_account).grid(row=3, column=2, padx=8, pady=8)

        ttk.Button(box, text='إزالة ربط Google', command=self.unlink_google_account).grid(row=4, column=2, padx=8, pady=8)

        ttk.Label(box, text='طريقة الاستعادة: عند نسيان كلمة المرور، يتم التحقق من حساب Google المرتبط ثم يسمح النظام بتعيين كلمة مرور جديدة.',
                  foreground='#555555', wraplength=800).grid(row=5, column=0, columnspan=3, padx=8, pady=12, sticky='e')

        theme_box = ttk.LabelFrame(tab, text='مظهر النظام', padding=15)
        theme_box.pack(fill='x', padx=20, pady=(0,20))
        ttk.Label(theme_box, text='لون الواجهة:').grid(row=0, column=0, padx=8, pady=8, sticky='e')
        self.theme_var = tk.StringVar(value=self.get_setting('لون_الواجهة', 'أزرق'))
        theme_combo = ttk.Combobox(theme_box, textvariable=self.theme_var,
                                   values=['أزرق', 'أخضر', 'رمادي', 'بني'],
                                   state='readonly', width=18)
        theme_combo.grid(row=0, column=1, padx=8, pady=8, sticky='w')
        theme_combo.bind('<<ComboboxSelected>>', self.change_theme)

        dept_box = ttk.LabelFrame(tab, text='إدارة الشعب', padding=15)
        dept_box.pack(fill='x', padx=20, pady=(0,20))
        ttk.Button(
            dept_box,
            text='🏢  إدارة الشعب',
            command=self.open_departments_window
        ).pack(side='right', padx=8, pady=5)
        ttk.Label(
            dept_box,
            text='إضافة وحذف وتعديل الشعب بدون تغيير بيانات المنتسبين.',
            foreground='#555555'
        ).pack(side='right', padx=8, pady=5)

        ttk.Label(theme_box, text='ملاحظة: الإعدادات تحفظ داخل قاعدة البيانات المحلية فقط.',
                  foreground='#555555').grid(row=1, column=0, columnspan=2, padx=8, pady=12, sticky='w')

    def save_recovery_email(self):
        email = self.recovery_var.get().strip()
        if '@' not in email or '.' not in email.split('@')[-1]:
            messagebox.showwarning('تنبيه', 'أدخل بريداً إلكترونياً صحيحاً.', parent=self.root)
            return
        self.set_setting('بريد_الاستعادة', email)
        messagebox.showinfo('تم', 'تم حفظ بريد الاستعادة.', parent=self.root)

    def link_google_account(self):
        if not GOOGLE_LIBS_AVAILABLE:
            messagebox.showerror('مكتبات Google غير مثبتة',
                                 'ثبت مكتبات Google أولاً بواسطة ملف تثبيت Google المرفق مع النظام.', parent=self.root)
            return
        credentials_path = BASE_DIR / 'credentials.json'
        if not credentials_path.exists():
            messagebox.showinfo('إعداد Google',
                'لا يوجد ملف credentials.json بعد.\n\nبعد إنشاء OAuth Client من Google Cloud، ضع ملف credentials.json بجانب البرنامج ثم اضغط هذا الزر مرة أخرى.', parent=self.root)
            return
        try:
            scopes = ['openid', 'email', 'profile']
            flow = InstalledAppFlow.from_client_secrets_file(str(credentials_path), scopes=scopes)
            creds = flow.run_local_server(port=0, open_browser=True)

            # بعد اكتمال OAuth نقرأ هوية الحساب مباشرة من Google.
            import requests
            info = requests.get(
                'https://openidconnect.googleapis.com/v1/userinfo',
                headers={'Authorization': f'Bearer {creds.token}'},
                timeout=20
            )
            info.raise_for_status()
            data = info.json()
            email = (data.get('email') or '').strip()
            sub = (data.get('sub') or '').strip()
            if not email or not sub:
                raise RuntimeError('تم تسجيل الدخول لكن لم تصل بيانات البريد من Google.')

            # البريد الإلكتروني هو البريد المعتمد للنظام، ويُحفظ محلياً داخل نفس قاعدة البيانات.
            self.set_setting('بريد_الاستعادة', email)
            self.set_setting('Google_Email', email)
            self.set_setting('Google_Sub', sub)
            self.conn.commit()

            # تحديث الشاشة فوراً.
            self.recovery_var.set(email)
            self.google_status_var.set(email)
            self.root.update_idletasks()
            messagebox.showinfo('تم الربط', f'تم ربط حساب Google بنجاح:\n{email}', parent=self.root)
        except Exception as e:
            messagebox.showerror('تعذر تسجيل الدخول إلى Google',
                                 f'اكتملت نافذة Google لكن تعذر حفظ الحساب داخل النظام.\n\nالتفاصيل:\n{e}', parent=self.root)

    def unlink_google_account(self):
        if not self.get_setting('Google_Email', ''):
            messagebox.showinfo('Google', 'لا يوجد حساب Google مربوط.', parent=self.root)
            return
        if messagebox.askyesno('إزالة الربط', 'هل تريد إزالة ربط حساب Google؟', parent=self.root):
            self.set_setting('Google_Email', '')
            self.set_setting('Google_Sub', '')
            self.google_status_var.set('غير مربوط')
            messagebox.showinfo('تم', 'تمت إزالة ربط Google. بريد الاستعادة بقي محفوظاً.', parent=self.root)

    def change_theme(self, event=None):
        value = self.theme_var.get()
        self.set_setting('لون_الواجهة', value)
        self.apply_theme(value)

    def change_password(self):
        old = simpledialog.askstring('تغيير كلمة المرور', 'أدخل كلمة المرور القديمة:',
                                     show='*', parent=self.root)
        if old is None:
            return
        if self.hash_password(old) != self.get_setting('كلمة_المرور'):
            messagebox.showerror('خطأ', 'كلمة المرور القديمة غير صحيحة.', parent=self.root)
            return
        new = simpledialog.askstring('تغيير كلمة المرور', 'أدخل كلمة المرور الجديدة:',
                                     show='*', parent=self.root)
        if new is None:
            return
        if len(new) < 4:
            messagebox.showwarning('تنبيه', 'كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل.', parent=self.root)
            return
        confirm = simpledialog.askstring('تغيير كلمة المرور', 'أعد إدخال كلمة المرور الجديدة:',
                                         show='*', parent=self.root)
        if confirm != new:
            messagebox.showerror('خطأ', 'كلمتا المرور غير متطابقتين.', parent=self.root)
            return
        self.set_setting('كلمة_المرور', self.hash_password(new))
        messagebox.showinfo('تم', 'تم تغيير كلمة المرور بنجاح.', parent=self.root)

    def make_tree(self, parent, columns, headings, widths=None):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, padx=8, pady=8)
        tree = ttk.Treeview(frame, columns=columns, show="headings")
        for i, c in enumerate(columns):
            tree.heading(c, text=headings[i], anchor="center")
            tree.column(c, width=(widths[i] if widths else 130), anchor="center")
        sy = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        tree.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def build_employees_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="👥  المنتسبون")
        form = ttk.LabelFrame(tab, text="بيانات المنتسب", padding=8)
        form.pack(fill="x", padx=8, pady=8)

        self.ev = {k: tk.StringVar() for k in [
            "الرقم_الوظيفي","الاسم_الكامل","اسم_الأم","الجنس","تاريخ_الميلاد","رقم_الهاتف",
            "العنوان","رقم_الشعبة","الفرع_الوحدة","المسمى_الوظيفي","نوع_التعيين","تاريخ_التعيين",
            "التحصيل_الدراسي","الحالة_الزوجية","تاريخ_التثبيت","الحالة","ملاحظات"
        ]}

        fields = list(self.ev.keys())
        for i, k in enumerate(fields):
            r = i // 4
            c = (i % 4) * 2
            ttk.Label(form, text=k.replace("_", " ")).grid(row=r, column=c, padx=4, pady=3, sticky="e")
            if k == "رقم_الشعبة":
                w = ttk.Combobox(form, textvariable=self.ev[k], state="readonly", width=28)
                w.grid(row=r, column=c+1, padx=4, pady=3, sticky="ew")
                self.section_combo = w
            elif k in ("الجنس","نوع_التعيين","الحالة_الزوجية","الحالة"):
                vals = {
                    "الجنس":["ذكر","أنثى"],
                    "نوع_التعيين":["دائمي","عقد","أجر يومي"],
                    "الحالة_الزوجية":["أعزب","متزوج","مطلق","أرمل"],
                    "الحالة":["مثبت","غير مثبت","منقول","متقاعد"]
                }[k]
                w = ttk.Combobox(form, textvariable=self.ev[k], values=vals, state="readonly", width=20)
                w.grid(row=r, column=c+1, padx=4, pady=3, sticky="ew")
            else:
                ttk.Entry(form, textvariable=self.ev[k], width=22, justify="right").grid(
                    row=r, column=c+1, padx=4, pady=3, sticky="ew"
                )
        for c in range(8):
            form.columnconfigure(c, weight=1)

        ttk.Label(form, text="الشعبة:").grid(row=0, column=6, padx=4, pady=3, sticky="e")
        ttk.Label(form, text="قسم التربية والتعليم",
                  font=("Tahoma", 10, "bold")).grid(row=0, column=7, padx=4, pady=3, sticky="w")

        btn = ttk.Frame(tab)
        btn.pack(fill="x", padx=8)
        ttk.Button(btn, text="منتسب جديد", command=self.clear_employee).pack(side="right", padx=3)
        ttk.Button(btn, text="حفظ / إضافة", command=self.save_employee).pack(side="right", padx=3)
        ttk.Button(btn, text="تعديل المحدد", command=self.update_employee).pack(side="right", padx=3)
        ttk.Button(btn, text="حذف المحدد", command=self.delete_employee).pack(side="right", padx=3)
        ttk.Label(btn, text="بحث:").pack(side="left")
        self.emp_search = tk.StringVar()
        se = ttk.Entry(btn, textvariable=self.emp_search, width=25)
        se.pack(side="left", padx=5)
        se.bind("<KeyRelease>", lambda e: self.load_employees())

        ttk.Label(btn, text="الشعبة:").pack(side="left", padx=(10,2))
        self.emp_dept_filter = tk.StringVar(value="الكل")
        self.emp_dept_cb = ttk.Combobox(btn, textvariable=self.emp_dept_filter, state="readonly", width=24)
        self.emp_dept_cb.pack(side="left", padx=3)
        self.emp_dept_cb.bind("<<ComboboxSelected>>", lambda e: self.load_employees())

        ttk.Label(btn, text="الحالة:").pack(side="left", padx=(10,2))
        self.emp_status_filter = tk.StringVar(value="الكل")
        self.emp_status_cb = ttk.Combobox(btn, textvariable=self.emp_status_filter,
                                           values=["الكل","مثبت","غير مثبت","منقول","متقاعد","مستمر بالخدمة"],
                                           state="readonly", width=15)
        self.emp_status_cb.pack(side="left", padx=3)
        self.emp_status_cb.bind("<<ComboboxSelected>>", lambda e: self.load_employees())

        self.emp_tree = self.make_tree(
            tab,
            ("id","job","name","phone","section","unit","title","status"),
            ["الرقم","الرقم الوظيفي","الاسم الكامل","الهاتف","الشعبة","الفرع / الوحدة","المسمى الوظيفي","الحالة"],
            [60,100,230,120,180,180,160,100]
        )
        self.emp_tree.bind("<<TreeviewSelect>>", self.on_employee_select)

    def sections(self):
        return [(r[0], r[1]) for r in self.q("SELECT رقم_الشعبة,اسم_الشعبة FROM الشعب ORDER BY رقم_الشعبة")]

    def refresh_sections(self):
        vals = [f"{i} - {n}" for i, n in self.sections()]
        self.section_combo["values"] = vals
        if hasattr(self, "emp_dept_cb"):
            self.emp_dept_cb["values"] = ["الكل"] + vals
            if self.emp_dept_filter.get() not in (["الكل"] + vals):
                self.emp_dept_filter.set("الكل")

    def section_id(self):
        s = self.ev["رقم_الشعبة"].get()
        if not s:
            return None
        try:
            return int(s.split(" - ", 1)[0])
        except Exception:
            return None

    def clear_employee(self):
        self.selected_employee_id = None
        for v in self.ev.values():
            v.set("")
        self.ev["الجنس"].set("ذكر")
        self.ev["نوع_التعيين"].set("دائمي")
        self.ev["الحالة"].set("مثبت")
        self.refresh_sections()

    def save_employee(self):
        name = self.ev["الاسم_الكامل"].get().strip()
        if not name:
            messagebox.showwarning("تنبيه", "أدخل الاسم الكامل.")
            return
        try:
            self.q("""INSERT INTO المنتسبون
            (الرقم_الوظيفي,الاسم_الكامل,اسم_الأم,الجنس,تاريخ_الميلاد,رقم_الهاتف,العنوان,رقم_القسم,
             المسمى_الوظيفي,نوع_التعيين,تاريخ_التعيين,التحصيل_الدراسي,الحالة_الزوجية,تاريخ_التثبيت,الحالة,ملاحظات,
             رقم_الشعبة,الفرع_الوحدة)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                self.ev["الرقم_الوظيفي"].get() or None,
                name,
                self.ev["اسم_الأم"].get(),
                self.ev["الجنس"].get(),
                self.ev["تاريخ_الميلاد"].get(),
                self.ev["رقم_الهاتف"].get(),
                self.ev["العنوان"].get(),
                None,
                self.ev["المسمى_الوظيفي"].get(),
                self.ev["نوع_التعيين"].get(),
                self.ev["تاريخ_التعيين"].get(),
                self.ev["التحصيل_الدراسي"].get(),
                self.ev["الحالة_الزوجية"].get(),
                self.ev["تاريخ_التثبيت"].get(),
                self.ev["الحالة"].get(),
                self.ev["ملاحظات"].get(),
                self.section_id(),
                self.ev["الفرع_الوحدة"].get()
            ))
            self.commit()
            self.load_employees()
            self.clear_employee()
            messagebox.showinfo("تم", "تمت إضافة المنتسب.")
        except sqlite3.IntegrityError:
            messagebox.showerror("خطأ", "الرقم الوظيفي مستخدم مسبقاً.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def update_employee(self):
        if not self.selected_employee_id:
            messagebox.showwarning("تنبيه", "حدد منتسباً أولاً.")
            return
        try:
            self.q("""UPDATE المنتسبون SET الرقم_الوظيفي=?,الاسم_الكامل=?,اسم_الأم=?,الجنس=?,تاريخ_الميلاد=?,
            رقم_الهاتف=?,العنوان=?,رقم_القسم=?,المسمى_الوظيفي=?,نوع_التعيين=?,تاريخ_التعيين=?,
            التحصيل_الدراسي=?,الحالة_الزوجية=?,تاريخ_التثبيت=?,الحالة=?,ملاحظات=?,
            رقم_الشعبة=?,الفرع_الوحدة=? WHERE رقم_المنتسب=?""",
            (
                self.ev["الرقم_الوظيفي"].get() or None,
                self.ev["الاسم_الكامل"].get(),
                self.ev["اسم_الأم"].get(),
                self.ev["الجنس"].get(),
                self.ev["تاريخ_الميلاد"].get(),
                self.ev["رقم_الهاتف"].get(),
                self.ev["العنوان"].get(),
                None,
                self.ev["المسمى_الوظيفي"].get(),
                self.ev["نوع_التعيين"].get(),
                self.ev["تاريخ_التعيين"].get(),
                self.ev["التحصيل_الدراسي"].get(),
                self.ev["الحالة_الزوجية"].get(),
                self.ev["تاريخ_التثبيت"].get(),
                self.ev["الحالة"].get(),
                self.ev["ملاحظات"].get(),
                self.section_id(),
                self.ev["الفرع_الوحدة"].get(),
                self.selected_employee_id
            ))
            self.commit()
            self.load_employees()
            messagebox.showinfo("تم", "تم تعديل البيانات.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def delete_employee(self):
        if not self.selected_employee_id:
            messagebox.showwarning("تنبيه", "حدد منتسباً أولاً.")
            return
        if not messagebox.askyesno("تأكيد", "هل تريد حذف المنتسب؟"):
            return
        try:
            self.q("DELETE FROM المنتسبون WHERE رقم_المنتسب=?", (self.selected_employee_id,))
            self.commit()
            self.load_employees()
            self.clear_employee()
        except sqlite3.IntegrityError:
            messagebox.showerror("لا يمكن الحذف", "لدى هذا المنتسب سجلات مرتبطة. احذف السجلات المرتبطة أولاً.")

    def on_employee_select(self, event=None):
        sel = self.emp_tree.selection()
        if not sel:
            return
        vals = self.emp_tree.item(sel[0], "values")
        self.selected_employee_id = int(vals[0])
        row = self.q("SELECT * FROM المنتسبون WHERE رقم_المنتسب=?", (self.selected_employee_id,)).fetchone()
        if not row:
            return
        cols = [d[0] for d in self.q("SELECT * FROM المنتسبون LIMIT 0").description]
        d = dict(zip(cols, row))
        for k, v in self.ev.items():
            v.set("" if d.get(k) is None else str(d[k]))
        sec = d.get("رقم_الشعبة")
        if sec:
            name = self.q("SELECT اسم_الشعبة FROM الشعب WHERE رقم_الشعبة=?", (sec,)).fetchone()
            self.ev["رقم_الشعبة"].set(f"{sec} - {name[0]}" if name else str(sec))

    def load_employees(self):
        self.refresh_sections()
        for x in self.emp_tree.get_children():
            self.emp_tree.delete(x)
        s = self.emp_search.get().strip()
        sql = """SELECT م.رقم_المنتسب,م.الرقم_الوظيفي,م.الاسم_الكامل,م.رقم_الهاتف,
                 COALESCE(ش.اسم_الشعبة,''),COALESCE(م.الفرع_الوحدة,''),
                 م.المسمى_الوظيفي,م.الحالة
                 FROM المنتسبون م LEFT JOIN الشعب ش ON ش.رقم_الشعبة=م.رقم_الشعبة"""
        conditions = []
        params = []
        if s:
            conditions.append("""(م.الاسم_الكامل LIKE ? OR م.الرقم_الوظيفي LIKE ?
                               OR م.رقم_الهاتف LIKE ? OR م.المسمى_الوظيفي LIKE ?)""")
            params += [f"%{s}%"] * 4
        dept_filter = getattr(self, "emp_dept_filter", tk.StringVar(value="الكل")).get()
        if dept_filter and dept_filter != "الكل":
            try:
                section_id = int(dept_filter.split(" - ", 1)[0])
                conditions.append("م.رقم_الشعبة=?")
                params.append(section_id)
            except Exception:
                pass
        status_filter = getattr(self, "emp_status_filter", tk.StringVar(value="الكل")).get()
        if status_filter and status_filter != "الكل":
            conditions.append("م.الحالة=?")
            params.append(status_filter)
        if conditions:
            sql += " WHERE " + " AND ".join(conditions)
        sql += " ORDER BY م.رقم_المنتسب"
        for r in self.q(sql, params):
            self.emp_tree.insert("", "end", values=r)

    def employee_choices(self):
        # عرض الاسم أولاً ثم الرقم لتسهيل الاختيار
        return [(r[0], f"{r[1]} - {r[0]}") for r in self.q(
            "SELECT رقم_المنتسب,الاسم_الكامل FROM المنتسبون ORDER BY الاسم_الكامل"
        )]

    def generic_record_tab(self, title, table, fields, display_cols, headings, idcol):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text=title)
        form = ttk.LabelFrame(tab, text=f"بيانات {title}", padding=8)
        form.pack(fill="x", padx=8, pady=8)

        vars = {k: tk.StringVar() for k in fields}
        setattr(self, f"v_{table}", vars)

        for i, k in enumerate(fields):
            r = i // 4
            c = (i % 4) * 2
            ttk.Label(form, text=k.replace("_", " ")).grid(row=r, column=c, padx=4, pady=4, sticky="e")
            if k == "رقم_المنتسب":
                cb = ttk.Combobox(form, textvariable=vars[k], state="readonly", width=32)
                cb["values"] = [x[1] for x in self.employee_choices()]
                cb.grid(row=r, column=c+1, padx=4, pady=4, sticky="ew")
                setattr(self, f"cb_{table}", cb)
            else:
                ttk.Entry(form, textvariable=vars[k], width=24, justify="right").grid(
                    row=r, column=c+1, padx=4, pady=4, sticky="ew"
                )
        for c in range(8):
            form.columnconfigure(c, weight=1)

        b = ttk.Frame(tab)
        b.pack(fill="x", padx=8)
        ttk.Button(b, text="سجل جديد", command=lambda t=table: self.clear_record(t)).pack(side="right", padx=3)
        ttk.Button(b, text="حفظ / إضافة", command=lambda t=table: self.save_record(t)).pack(side="right", padx=3)
        ttk.Button(b, text="تعديل المحدد", command=lambda t=table: self.update_record(t)).pack(side="right", padx=3)
        ttk.Button(b, text="حذف المحدد", command=lambda t=table: self.delete_record(t)).pack(side="right", padx=3)

        # بحث مستقل لكل سجل
        search_bar = ttk.Frame(tab)
        search_bar.pack(fill="x", padx=8, pady=(2, 0))
        ttk.Label(search_bar, text="بحث باسم المنتسب أو داخل السجلات:").pack(side="right", padx=4)
        search_var = tk.StringVar()
        setattr(self, f"search_{table}", search_var)
        search_entry = ttk.Entry(search_bar, textvariable=search_var, width=32, justify="right")
        search_entry.pack(side="right", padx=4)
        search_entry.bind("<KeyRelease>", lambda e, t=table: self.load_table(t))
        search_entry.bind("<Return>", lambda e, t=table: self.load_table(t))
        ttk.Button(search_bar, text="بحث", command=lambda t=table: self.load_table(t)).pack(side="right", padx=3)
        ttk.Button(search_bar, text="مسح البحث", command=lambda t=table: self.clear_table_search(t)).pack(side="right", padx=3)

        tree_columns = tuple([idcol, "اسم_المنتسب"] + display_cols)
        tree_headings = [idcol, "اسم المنتسب"] + headings
        tree = self.make_tree(tab, tree_columns, tree_headings,
                              [70, 220] + [150] * len(display_cols))
        setattr(self, f"tree_{table}", tree)
        tree.bind("<<TreeviewSelect>>", lambda e, t=table: self.on_record_select(t))

    def build_leaves_tab(self):
        self.generic_record_tab("الإجازات", "الإجازات",
            ["رقم_المنتسب","نوع_الإجازة","من_تاريخ","إلى_تاريخ","عدد_الأيام","سبب_الإجازة","حالة_الإجازة","ملاحظات"],
            ["نوع_الإجازة","من_تاريخ","إلى_تاريخ","عدد_الأيام","حالة_الإجازة"],
            ["نوع الإجازة","من تاريخ","إلى تاريخ","الأيام","الحالة"], "رقم_الإجازة")

        # حساب عدد الأيام تلقائياً عند كتابة التاريخين بصيغة YYYY-MM-DD
        self.v_الإجازات["من_تاريخ"].trace_add("write", self.calc_leave_days)
        self.v_الإجازات["إلى_تاريخ"].trace_add("write", self.calc_leave_days)

    def build_absences_tab(self):
        self.generic_record_tab("الغيابات", "الغيابات",
            ["رقم_المنتسب","تاريخ_الغياب","نوع_الغياب","السبب","الإجراء","ملاحظات"],
            ["تاريخ_الغياب","نوع_الغياب","السبب","الإجراء"],
            ["التاريخ","النوع","السبب","الإجراء"], "رقم_الغياب")

    def build_penalties_tab(self):
        self.generic_record_tab("العقوبات", "العقوبات",
            ["رقم_المنتسب","تاريخ_العقوبة","نوع_العقوبة","سبب_العقوبة","الجهة_المصدرة","رقم_الأمر","تاريخ_الأمر","ملاحظات"],
            ["تاريخ_العقوبة","نوع_العقوبة","سبب_العقوبة","الجهة_المصدرة","رقم_الأمر"],
            ["التاريخ","النوع","السبب","الجهة","رقم الأمر"], "رقم_العقوبة")

    def build_attendance_tab(self):
        self.generic_record_tab("الحضور", "الحضور",
            ["رقم_المنتسب","التاريخ","وقت_الحضور","وقت_الانصراف","حالة_الحضور","ملاحظات"],
            ["التاريخ","وقت_الحضور","وقت_الانصراف","حالة_الحضور"],
            ["التاريخ","الحضور","الانصراف","الحالة"], "رقم_السجل")

    def clear_record(self, table):
        vars = getattr(self, f"v_{table}")
        for v in vars.values():
            v.set("")
        cb = getattr(self, f"cb_{table}", None)
        if cb:
            cb["values"] = [x[1] for x in self.employee_choices()]
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        setattr(self, f"selected_{key}_id", None)

    def calc_leave_days(self, event=None):
        try:
            vars = self.v_الإجازات
            a = vars["من_تاريخ"].get().strip()
            b = vars["إلى_تاريخ"].get().strip()
            from datetime import datetime
            start = datetime.strptime(a, "%Y-%m-%d")
            end = datetime.strptime(b, "%Y-%m-%d")
            days = (end - start).days + 1
            if days >= 0:
                vars["عدد_الأيام"].set(str(days))
        except Exception:
            pass

    def save_record(self, table):
        vars = getattr(self, f"v_{table}")
        data = {k: v.get().strip() for k, v in vars.items()}
        if not data.get("رقم_المنتسب"):
            messagebox.showwarning("تنبيه", "اختر المنتسب.")
            return
        data["رقم_المنتسب"] = self.emp_id_from_text(data["رقم_المنتسب"])
        cols = list(data.keys())
        vals = [data[c] if data[c] != "" else None for c in cols]
        try:
            qs = ",".join(["?"] * len(cols))
            self.q(f'INSERT INTO "{table}" ({",".join(cols)}) VALUES ({qs})', vals)
            self.commit()
            self.load_table(table)
            messagebox.showinfo("تم", "تم حفظ السجل.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def update_record(self, table):
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        sid = getattr(self, f"selected_{key}_id")
        if not sid:
            messagebox.showwarning("تنبيه", "حدد سجلاً أولاً.")
            return
        vars = getattr(self, f"v_{table}")
        data = {k: v.get().strip() for k, v in vars.items()}
        data["رقم_المنتسب"] = self.emp_id_from_text(data["رقم_المنتسب"])
        try:
            sets = ",".join([f'"{c}"=?' for c in data])
            vals = [data[c] if data[c] != "" else None for c in data]
            vals.append(sid)
            self.q(f'UPDATE "{table}" SET {sets} WHERE "{self.idcol(table)}"=?', vals)
            self.commit()
            self.load_table(table)
            messagebox.showinfo("تم", "تم تعديل السجل.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def delete_record(self, table):
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        sid = getattr(self, f"selected_{key}_id")
        if not sid:
            return
        if not messagebox.askyesno("تأكيد", "هل تريد حذف السجل؟"):
            return
        try:
            self.q(f'DELETE FROM "{table}" WHERE "{self.idcol(table)}"=?', (sid,))
            self.commit()
            self.load_table(table)
            self.clear_record(table)
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def idcol(self, table):
        return {"الإجازات":"رقم_الإجازة","الغيابات":"رقم_الغياب","العقوبات":"رقم_العقوبة","الحضور":"رقم_السجل"}[table]

    def emp_id_from_text(self, text):
        # يدعم الصيغة الجديدة "الاسم - الرقم" والقديمة "الرقم - الاسم"
        text = (text or "").strip()
        if " - " in text:
            parts = text.rsplit(" - ", 1)
            try:
                return int(parts[1].strip())
            except Exception:
                try:
                    return int(parts[0].strip())
                except Exception:
                    return None
        try:
            return int(text)
        except Exception:
            return None

    def on_record_select(self, table):
        tree = getattr(self, f"tree_{table}")
        sel = tree.selection()
        if not sel:
            return
        sid = int(tree.item(sel[0], "values")[0])
        key = {"الإجازات":"leave","الغيابات":"absence","العقوبات":"penalty","الحضور":"attendance"}[table]
        setattr(self, f"selected_{key}_id", sid)

        cols = [r[1] for r in self.q(f'PRAGMA table_info("{table}")')]
        row = self.q(f'SELECT * FROM "{table}" WHERE "{self.idcol(table)}"=?', (sid,)).fetchone()
        d = dict(zip(cols, row))
        vars = getattr(self, f"v_{table}")
        for k, v in vars.items():
            val = d.get(k)
            if k == "رقم_المنتسب" and val is not None:
                name = self.q("SELECT الاسم_الكامل FROM المنتسبون WHERE رقم_المنتسب=?", (val,)).fetchone()
                v.set(f"{name[0]} - {val}" if name else str(val))
            else:
                v.set("" if val is None else str(val))

    def clear_table_search(self, table):
        var = getattr(self, f"search_{table}", None)
        if var is not None:
            var.set("")
            self.load_table(table)

    def load_table(self, table):
        tree = getattr(self, f"tree_{table}")
        for x in tree.get_children():
            tree.delete(x)

        idc = self.idcol(table)
        maps = {
            "الإجازات":["نوع_الإجازة","من_تاريخ","إلى_تاريخ","عدد_الأيام","حالة_الإجازة"],
            "الغيابات":["تاريخ_الغياب","نوع_الغياب","السبب","الإجراء"],
            "العقوبات":["تاريخ_العقوبة","نوع_العقوبة","سبب_العقوبة","الجهة_المصدرة","رقم_الأمر"],
            "الحضور":["التاريخ","وقت_الحضور","وقت_الانصراف","حالة_الحضور"]
        }

        display_cols = maps[table]
        select_cols = ",".join([f't."{c}"' for c in display_cols])
        sql = f'''SELECT t."{idc}", COALESCE(m."الاسم_الكامل",'') AS "اسم_المنتسب", {select_cols}
                  FROM "{table}" t
                  LEFT JOIN "المنتسبون" m ON m."رقم_المنتسب" = t."رقم_المنتسب"'''
        params = []

        search = getattr(self, f"search_{table}", tk.StringVar()).get().strip()
        if search:
            conditions = ['m."الاسم_الكامل" LIKE ?']
            params.append(f"%{search}%")
            for c in display_cols:
                conditions.append(f'CAST(t."{c}" AS TEXT) LIKE ?')
                params.append(f"%{search}%")
            sql += " WHERE " + " OR ".join(conditions)

        sql += f' ORDER BY t."{idc}" DESC'

        for r in self.q(sql, params):
            tree.insert("", "end", values=r)

        cb = getattr(self, f"cb_{table}", None)
        if cb:
            cb["values"] = [x[1] for x in self.employee_choices()]

    def open_departments_window(self):
        win = tk.Toplevel(self.root)
        win.title("إدارة الشعب")
        win.geometry("700x500")
        win.minsize(600, 420)
        win.transient(self.root)

        top = ttk.Frame(win, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="رقم الشعبة:").pack(side="right", padx=4)
        self.dept_id_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.dept_id_var, width=12, justify="right").pack(side="right", padx=4)

        ttk.Label(top, text="اسم الشعبة:").pack(side="right", padx=4)
        self.dept_name_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.dept_name_var, width=30, justify="right").pack(side="right", padx=4)

        ttk.Button(top, text="إضافة شعبة", command=self.add_department).pack(side="right", padx=4)
        ttk.Button(top, text="حذف الشعبة", command=self.delete_department).pack(side="right", padx=4)
        ttk.Button(top, text="تحديث", command=self.load_departments).pack(side="right", padx=4)

        self.dept_tree = self.make_tree(
            win, ("id","name"), ["رقم الشعبة","اسم الشعبة"], [120,400]
        )
        self.dept_tree.bind("<<TreeviewSelect>>", self.on_department_select)
        self.load_departments()

    def load_departments(self):
        if not hasattr(self, "dept_tree"):
            return
        for x in self.dept_tree.get_children():
            self.dept_tree.delete(x)
        for r in self.q("SELECT رقم_القسم,اسم_القسم FROM الأقسام ORDER BY رقم_القسم"):
            self.dept_tree.insert("", "end", values=r)
        self.refresh_sections()

    def on_department_select(self, event=None):
        sel = self.dept_tree.selection()
        if not sel:
            return
        r = self.dept_tree.item(sel[0], "values")
        self.dept_id_var.set(r[0])
        self.dept_name_var.set(r[1])

    def add_department(self):
        name = self.dept_name_var.get().strip()
        if not name:
            messagebox.showwarning("تنبيه", "أدخل اسم القسم.")
            return
        raw_id = self.dept_id_var.get().strip()
        try:
            if raw_id:
                self.q("INSERT INTO الأقسام (رقم_القسم,اسم_القسم) VALUES (?,?)", (int(raw_id), name))
            else:
                self.q("INSERT INTO الأقسام (اسم_القسم) VALUES (?)", (name,))
            self.commit()
            self.load_departments()
            self.dept_id_var.set("")
            self.dept_name_var.set("")
            messagebox.showinfo("تم", "تمت إضافة القسم.")
        except sqlite3.IntegrityError:
            messagebox.showerror("خطأ", "رقم القسم أو اسم القسم مستخدم مسبقاً.")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def delete_department(self):
        sel = self.dept_tree.selection()
        if not sel:
            messagebox.showwarning("تنبيه", "حدد القسم أولاً.")
            return
        dept_id = int(self.dept_tree.item(sel[0], "values")[0])
        used = self.q("SELECT COUNT(*) FROM المنتسبون WHERE رقم_القسم=?", (dept_id,)).fetchone()[0]
        if used:
            messagebox.showwarning("لا يمكن الحذف",
                                   f"هذا القسم مرتبط بـ {used} منتسب. غيّر أقسامهم أولاً.")
            return
        if not messagebox.askyesno("تأكيد", "هل تريد حذف القسم المحدد؟"):
            return
        try:
            self.q("DELETE FROM الأقسام WHERE رقم_القسم=?", (dept_id,))
            self.commit()
            self.load_departments()
            self.dept_id_var.set("")
            self.dept_name_var.set("")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def build_reports_tab(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="📊  التقارير")

        top = ttk.Frame(tab, padding=10)
        top.pack(fill="x")

        ttk.Button(top, text="تقرير المنتسبين", command=self.report_employees).pack(side="right", padx=4)
        ttk.Button(top, text="تقرير الإجازات", command=self.report_leaves).pack(side="right", padx=4)
        ttk.Button(top, text="تقرير الغيابات", command=self.report_absences).pack(side="right", padx=4)
        ttk.Button(top, text="تقرير العقوبات", command=self.report_penalties).pack(side="right", padx=4)
        ttk.Button(top, text="تقرير الحضور", command=self.report_attendance).pack(side="right", padx=4)

        ttk.Button(top, text="حفظ Excel/CSV", command=self.save_report_csv).pack(side="left", padx=4)
        ttk.Button(top, text="طباعة التقرير", command=self.print_report).pack(side="left", padx=4)
        ttk.Button(top, text="إحصائيات", command=self.show_stats).pack(side="left", padx=4)

        self.report_title = tk.StringVar(value="اختر نوع التقرير")
        ttk.Label(tab, textvariable=self.report_title,
                  font=("Tahoma", 14, "bold")).pack(fill="x", padx=10, pady=(0, 5))

        frame = ttk.Frame(tab)
        frame.pack(fill="both", expand=True, padx=10, pady=5)

        self.report_tree = ttk.Treeview(frame, show="headings")
        self.report_tree.grid(row=0, column=0, sticky="nsew")
        sy = ttk.Scrollbar(frame, orient="vertical", command=self.report_tree.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=self.report_tree.xview)
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        self.report_tree.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

        style = ttk.Style()
        style.configure("Report.Treeview", rowheight=30, font=("Tahoma", 10))
        style.configure("Report.Treeview.Heading", font=("Tahoma", 10, "bold"))
        self.report_tree.configure(style="Report.Treeview")

        self.current_report_title = ""
        self.current_report_headers = []
        self.current_report_rows = []

    def set_report(self, title, rows, headers):
        self.current_report_title = title
        self.current_report_headers = headers
        self.current_report_rows = rows
        self.report_title.set(title)

        for item in self.report_tree.get_children():
            self.report_tree.delete(item)

        cols = [f"c{i}" for i in range(len(headers))]
        self.report_tree["columns"] = cols

        for i, (col, heading) in enumerate(zip(cols, headers)):
            self.report_tree.heading(col, text=heading, anchor="center")
            width = 170
            if any(x in heading for x in ("الاسم", "المنتسب", "السبب")):
                width = 230
            elif any(x in heading for x in ("التاريخ", "من", "إلى")):
                width = 120
            elif any(x in heading for x in ("الأيام", "رقم")):
                width = 90
            self.report_tree.column(col, width=width, minwidth=80, anchor="center")

        for idx, row in enumerate(rows):
            vals = ["" if x is None else str(x) for x in row]
            self.report_tree.insert("", "end", values=vals, tags=("even" if idx % 2 == 0 else "odd",))

        self.report_tree.tag_configure("even", background="#f7f7f7")
        self.report_tree.tag_configure("odd", background="#ffffff")

    def report_employees(self):
        rows = self.q("""SELECT م.الرقم_الوظيفي,م.الاسم_الكامل,
                         ش.اسم_الشعبة,COALESCE(م.الفرع_الوحدة,''),
                         م.المسمى_الوظيفي,م.الحالة
                         FROM المنتسبون م LEFT JOIN الشعب ش ON ش.رقم_الشعبة=م.رقم_الشعبة
                         ORDER BY م.رقم_المنتسب""").fetchall()
        self.set_report("تقرير المنتسبين - قسم التربية والتعليم", rows,
                        ["الرقم الوظيفي","الاسم الكامل","الشعبة","الفرع / الوحدة","المسمى الوظيفي","الحالة"])

    def report_leaves(self):
        rows = self.q("""SELECT م.الاسم_الكامل,إ.نوع_الإجازة,إ.من_تاريخ,إ.إلى_تاريخ,إ.عدد_الأيام,إ.حالة_الإجازة
                         FROM الإجازات إ JOIN المنتسبون م ON م.رقم_المنتسب=إ.رقم_المنتسب
                         ORDER BY إ.رقم_الإجازة DESC""").fetchall()
        self.set_report("تقرير الإجازات", rows,
                        ["المنتسب","نوع الإجازة","من","إلى","الأيام","الحالة"])

    def report_absences(self):
        rows = self.q("""SELECT م.الاسم_الكامل,غ.تاريخ_الغياب,غ.نوع_الغياب,غ.السبب,غ.الإجراء
                         FROM الغيابات غ JOIN المنتسبون م ON م.رقم_المنتسب=غ.رقم_المنتسب
                         ORDER BY غ.رقم_الغياب DESC""").fetchall()
        self.set_report("تقرير الغيابات", rows,
                        ["المنتسب","التاريخ","النوع","السبب","الإجراء"])

    def report_penalties(self):
        rows = self.q("""SELECT م.الاسم_الكامل,ع.تاريخ_العقوبة,ع.نوع_العقوبة,ع.سبب_العقوبة,ع.الجهة_المصدرة,ع.رقم_الأمر
                         FROM العقوبات ع JOIN المنتسبون م ON م.رقم_المنتسب=ع.رقم_المنتسب
                         ORDER BY ع.رقم_العقوبة DESC""").fetchall()
        self.set_report("تقرير العقوبات", rows,
                        ["المنتسب","التاريخ","النوع","السبب","الجهة","رقم الأمر"])

    def report_attendance(self):
        rows = self.q("""SELECT م.الاسم_الكامل,ح.التاريخ,ح.وقت_الحضور,ح.وقت_الانصراف,ح.حالة_الحضور
                         FROM الحضور ح JOIN المنتسبون م ON م.رقم_المنتسب=ح.رقم_المنتسب
                         ORDER BY ح.رقم_السجل DESC""").fetchall()
        self.set_report("تقرير الحضور", rows,
                        ["المنتسب","التاريخ","الحضور","الانصراف","الحالة"])

    def save_report_csv(self):
        if not self.current_report_rows:
            messagebox.showwarning("تنبيه", "أنشئ تقريراً أولاً.")
            return
        import csv
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV - يفتح في Excel","*.csv")],
            title="حفظ التقرير كجدول"
        )
        if path:
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f)
                w.writerow(self.current_report_headers)
                w.writerows(self.current_report_rows)
            messagebox.showinfo("تم", "تم حفظ التقرير كجدول يمكن فتحه في Excel.")

    def print_report(self):
        if not self.current_report_rows:
            messagebox.showwarning("تنبيه", "أنشئ تقريراً أولاً.")
            return

        import html, os
        headers_html = "".join(f"<th>{html.escape(str(h))}</th>" for h in self.current_report_headers)
        rows_html = []
        for row in self.current_report_rows:
            cells = "".join(f"<td>{html.escape('' if x is None else str(x))}</td>" for x in row)
            rows_html.append(f"<tr>{cells}</tr>")

        page = f"""<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>{html.escape(self.current_report_title)}</title>
<style>
body {{ font-family: Tahoma, Arial, sans-serif; direction: rtl; margin: 25px; }}
h2 {{ text-align: center; margin-bottom: 20px; }}
table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
th, td {{ border: 1px solid #555; padding: 7px; text-align: center; }}
th {{ font-weight: bold; background: #eaeaea; }}
tr:nth-child(even) {{ background: #f7f7f7; }}
@media print {{ @page {{ size: A4 landscape; margin: 10mm; }} }}
</style>
<script>
window.addEventListener('load', function() {{
    setTimeout(function() {{ window.print(); }}, 500);
}});
</script>
</head>
<body>
<h2>{html.escape(self.current_report_title)}</h2>
<table><thead><tr>{headers_html}</tr></thead>
<tbody>{''.join(rows_html)}</tbody></table>
</body></html>"""

        path = BASE_DIR / "تقرير_للطباعة.html"
        try:
            path.write_text(page, encoding="utf-8")
            # لا نعتمد على ربط امتداد HTML في ويندوز، لأنه قد يكون غير مضبوط.
            # بدلاً من ذلك نفتحه في المتصفح الافتراضي مباشرة ثم تظهر نافذة الطباعة.
            import webbrowser
            opened = webbrowser.open(path.as_uri(), new=2)
            if not opened:
                raise RuntimeError("تعذر فتح التقرير في المتصفح الافتراضي.")
        except Exception as e:
            messagebox.showerror("خطأ في الطباعة",
                                 f"تعذر فتح تقرير الطباعة في المتصفح.\n"
                                 f"يمكنك فتح الملف يدوياً ثم اختيار طباعة:\n{path}\n\n{e}")

    def show_stats(self):
        try:
            emp = self.q("SELECT COUNT(*) FROM المنتسبون").fetchone()[0]
            leaves = self.q("SELECT COUNT(*) FROM الإجازات").fetchone()[0]
            absences = self.q("SELECT COUNT(*) FROM الغيابات").fetchone()[0]
            penalties = self.q("SELECT COUNT(*) FROM العقوبات").fetchone()[0]
            attendance = self.q("SELECT COUNT(*) FROM الحضور").fetchone()[0]
            msg = (
                f"عدد المنتسبين: {emp}\n"
                f"عدد الإجازات: {leaves}\n"
                f"عدد الغيابات: {absences}\n"
                f"عدد العقوبات: {penalties}\n"
                f"سجلات الحضور: {attendance}"
            )
            messagebox.showinfo("إحصائيات النظام", msg)
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def load_all(self):
        if not self.conn:
            return
        self.refresh_sections()
        self.load_employees()
        if hasattr(self, "dept_tree"):
            self.load_departments()
        for t in ("الإجازات","الغيابات","العقوبات","الحضور"):
            self.load_table(t)

    def backup_db(self):
        try:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            target = BASE_DIR / f"نسخة_احتياطية_{stamp}.sqlite"
            shutil.copy2(DB_PATH, target)
            messagebox.showinfo("نسخة احتياطية", f"تم حفظ نسخة احتياطية:\n{target.name}")
        except Exception as e:
            messagebox.showerror("خطأ", str(e))

    def close(self):
        try:
            if self.conn:
                self.conn.close()
        finally:
            self.root.destroy()

def google_recovery(db_path):
    if not GOOGLE_LIBS_AVAILABLE:
        messagebox.showerror('Google', 'مكتبات Google غير مثبتة. شغّل تثبيت Google أولاً.')
        return False
    credentials_path = BASE_DIR / 'credentials.json'
    if not credentials_path.exists():
        messagebox.showinfo('Google', 'ملف credentials.json غير موجود بجانب البرنامج. جهّز ربط Google أولاً من الإعدادات.')
        return False
    conn = sqlite3.connect(str(db_path))
    try:
        row = conn.execute("SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='Google_Email'").fetchone()
        linked_email = (row[0] if row else '').strip().lower()
        linked_sub_row = conn.execute("SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='Google_Sub'").fetchone()
        linked_sub = linked_sub_row[0] if linked_sub_row else ''
        if not linked_email or not linked_sub:
            messagebox.showwarning('استعادة كلمة المرور', 'لا يوجد حساب Google مربوط بهذا النظام. يجب ربطه مسبقاً من الإعدادات.')
            return False
        scopes=['openid','email','profile']
        flow=InstalledAppFlow.from_client_secrets_file(str(credentials_path), scopes=scopes)
        creds=flow.run_local_server(port=0, open_browser=True)
        import requests
        r=requests.get('https://openidconnect.googleapis.com/v1/userinfo', headers={'Authorization': f'Bearer {creds.token}'}, timeout=20)
        r.raise_for_status()
        data=r.json()
        if data.get('email','').lower() != linked_email or data.get('sub','') != linked_sub:
            messagebox.showerror('رفض الاستعادة', 'حساب Google الذي سجلت به ليس الحساب المرتبط بهذا النظام.')
            return False
        new1=simpledialog.askstring('استعادة كلمة المرور', 'أدخل كلمة المرور الجديدة:', show='*')
        if new1 is None: return False
        if len(new1)<4:
            messagebox.showwarning('تنبيه','كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل.')
            return False
        new2=simpledialog.askstring('استعادة كلمة المرور', 'أعد إدخال كلمة المرور الجديدة:', show='*')
        if new1 != new2:
            messagebox.showerror('خطأ','كلمتا المرور غير متطابقتين.')
            return False
        conn.execute("UPDATE إعدادات_النظام SET القيمة=? WHERE المفتاح='كلمة_المرور'", (hashlib.sha256(new1.encode('utf-8')).hexdigest(),))
        conn.commit()
        messagebox.showinfo('تم', 'تمت استعادة كلمة المرور بنجاح. يمكنك الآن تسجيل الدخول.')
        return True
    except Exception as e:
        messagebox.showerror('Google', f'تعذر التحقق من حساب Google:\n{e}')
        return False
    finally:
        conn.close()

def verify_login(db_path):
    conn = None
    try:
        conn = sqlite3.connect(str(db_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS إعدادات_النظام (
                المفتاح TEXT PRIMARY KEY,
                القيمة TEXT NOT NULL
            )
        """)
        row = conn.execute(
            "SELECT القيمة FROM إعدادات_النظام WHERE المفتاح='كلمة_المرور'"
        ).fetchone()
        if not row:
            conn.execute(
                "INSERT INTO إعدادات_النظام (المفتاح, القيمة) VALUES (?, ?)",
                ('كلمة_المرور', hashlib.sha256('1234'.encode('utf-8')).hexdigest())
            )
            conn.commit()
            stored = hashlib.sha256('1234'.encode('utf-8')).hexdigest()
        else:
            stored = row[0]

        root = tk.Tk()
        root.withdraw()
        result = {'ok': False}
        login = tk.Toplevel(root)
        login.title('تسجيل الدخول')
        login.geometry('430x300')
        login.resizable(False, False)
        login.grab_set()
        ttk.Label(login, text=APP_TITLE, font=('Tahoma', 15, 'bold')).pack(pady=(20,8))
        ttk.Label(login, text='أدخل كلمة المرور أو استخدم حساب Google المرتبط').pack(pady=5)
        ent = ttk.Entry(login, show='*', width=32)
        ent.pack(pady=10)
        ent.focus_set()

        def do_password():
            if hashlib.sha256(ent.get().encode('utf-8')).hexdigest() == stored:
                result['ok']=True
                login.destroy()
            else:
                messagebox.showerror('خطأ', 'كلمة المرور غير صحيحة.', parent=login)

        def do_google():
            # Close the modal first so browser OAuth can proceed normally.
            login.destroy()
            if google_recovery(db_path):
                result['ok']=True
            # If recovery wasn't performed, result remains False.

        ttk.Button(login, text='دخول بكلمة المرور', command=do_password).pack(pady=5)
        ttk.Button(login, text='تسجيل الدخول بحساب Google', command=do_google).pack(pady=5)
        ttk.Button(login, text='نسيت كلمة المرور؟', command=do_google).pack(pady=5)
        login.protocol('WM_DELETE_WINDOW', login.destroy)
        root.wait_window(login)
        root.destroy()
        return result['ok']
    except Exception as e:
        try:
            if conn:
                conn.close()
        except Exception:
            pass
        messagebox.showerror('خطأ', f'تعذر تجهيز تسجيل الدخول:\n{e}')
        return False
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    if not DB_PATH.exists():
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('قاعدة البيانات', f'لم يتم العثور على قاعدة البيانات:\n{DB_PATH}\n\nضع ملف {DB_NAME} بجانب البرنامج.')
        root.destroy()
        raise SystemExit

    if not verify_login(DB_PATH):
        raise SystemExit

    root = tk.Tk()
    app = App(root)
    if app.conn:
        app.apply_theme()
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()
