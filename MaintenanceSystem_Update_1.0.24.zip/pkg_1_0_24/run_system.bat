@echo off
cd /d "%~dp0"
python MaintenanceSystem.py
pause
