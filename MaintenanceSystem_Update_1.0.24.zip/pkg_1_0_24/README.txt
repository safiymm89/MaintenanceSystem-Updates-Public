MaintenanceSystem Update 1.0.24

Changes:
- Restores the employee editing bar above the Personal Information section.
- Moves the employee edit controls to the agreed location above Personal Information.
- Slightly reduces the main program title size for a more balanced header.
- Preserves the 1.0.23 search and scrolling fixes.
- No database is included.
